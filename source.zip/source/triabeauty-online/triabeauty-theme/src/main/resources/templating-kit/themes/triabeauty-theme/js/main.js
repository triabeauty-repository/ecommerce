

document.load=hello