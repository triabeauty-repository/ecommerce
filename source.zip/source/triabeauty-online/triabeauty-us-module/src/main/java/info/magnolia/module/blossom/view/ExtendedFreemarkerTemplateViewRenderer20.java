/**
 * This file Copyright (c) 2003-2011 Magnolia International
 * Ltd.  (http://www.magnolia-cms.com). All rights reserved.
 *
 *
 * This file is dual-licensed under both the Magnolia
 * Network Agreement and the GNU General Public License.
 * You may elect to use one or the other of these licenses.
 *
 * This file is distributed in the hope that it will be
 * useful, but AS-IS and WITHOUT ANY WARRANTY; without even the
 * implied warranty of MERCHANTABILITY or FITNESS FOR A
 * PARTICULAR PURPOSE, TITLE, or NONINFRINGEMENT.
 * Redistribution, except as permitted by whichever of the GPL
 * or MNA you select, is prohibited.
 *
 * 1. For the GPL license (GPL), you can redistribute and/or
 * modify this file under the terms of the GNU General
 * Public License, Version 3, as published by the Free Software
 * Foundation.  You should have received a copy of the GNU
 * General Public License, Version 3 along with this program;
 * if not, write to the Free Software Foundation, Inc., 51
 * Franklin St, Fifth Floor, Boston, MA 02110-1301 USA.
 *
 * 2. For the Magnolia Network Agreement (MNA), this file
 * and the accompanying materials are made available under the
 * terms of the MNA which accompanies this distribution, and
 * is available at http://www.magnolia-cms.com/mna.html
 *
 * Any modifications to this file must keep this entire header
 * intact.
 *
 */
package info.magnolia.module.blossom.view;

import java.util.Map;
import javax.jcr.Node;
import javax.servlet.http.HttpServletRequest;

import org.springframework.web.servlet.support.RequestContext;
import org.springframework.web.servlet.view.AbstractTemplateView;

import info.magnolia.context.MgnlContext;
import info.magnolia.module.blossom.render.RenderContext;
import info.magnolia.rendering.context.RenderingContext;
import info.magnolia.rendering.engine.RenderException;
import info.magnolia.rendering.model.RenderingModel;
import info.magnolia.rendering.renderer.FreemarkerRenderer;
import info.magnolia.rendering.template.RenderableDefinition;

/**
 * Renders freemarker templates.
 * 
 * @since 1.0
 */
@SuppressWarnings("deprecation")
public class ExtendedFreemarkerTemplateViewRenderer20 extends
		FreemarkerRenderer {

	private boolean exposeModelAsRequestAttributes = true;
	private boolean exposeSpringMacroHelpers = true;

	public boolean isExposeModelAsRequestAttributes() {
		return exposeModelAsRequestAttributes;
	}

	public void setExposeModelAsRequestAttributes(
			boolean exposeModelAsRequestAttributes) {
		this.exposeModelAsRequestAttributes = exposeModelAsRequestAttributes;
	}

	public boolean isExposeSpringMacroHelpers() {
		return exposeSpringMacroHelpers;
	}

	public void setExposeSpringMacroHelpers(boolean exposeSpringMacroHelpers) {
		this.exposeSpringMacroHelpers = exposeSpringMacroHelpers;
	}

	@Override
	@SuppressWarnings("all")
	protected void setupContext(Map<String, Object> ctx, Node content,
			RenderableDefinition definition, RenderingModel<?> model,
			Object actionResult) {
		super.setupContext(ctx, content, definition, model, actionResult);
		ctx.putAll(RenderContext.get().getModel());
	}

	@Override
	protected String resolveTemplateScript(Node content,
			RenderableDefinition definition, RenderingModel<?> model,
			String actionResult) {
		return RenderContext.get().getTemplateScript();
	}

	@Override
	protected void onRender(Node content, RenderableDefinition definition,
			RenderingContext renderingCtx, Map<String, Object> ctx,
			String templateScript) throws RenderException {

		if (MgnlContext.isWebContext()) {

			Map<String, Object> model = ctx;

			// Expose RequestContext instance for Spring macros.
			// See
			// org.springframework.web.servlet.view.AbstractTemplateView#setExposeSpringMacroHelpers
			if (this.exposeSpringMacroHelpers) {
				model.put(
						AbstractTemplateView.SPRING_MACRO_REQUEST_CONTEXT_ATTRIBUTE,
						new RequestContext(MgnlContext.getWebContext()
								.getRequest(), MgnlContext.getWebContext()
								.getResponse(), MgnlContext.getWebContext()
								.getServletContext(), model));
			}

			// Expose the model objects in the given map as request attributes.
			// Necessary to let JSP tags access them, especially the spring form
			// taglib.
			// See
			// org.springframework.web.servlet.view.AbstractView#exposeModelAsRequestAttributes
			if (this.exposeModelAsRequestAttributes) {
				HttpServletRequest request = MgnlContext.getWebContext()
						.getRequest();
				for (Map.Entry<String, Object> entry : model.entrySet()) {
					String modelName = entry.getKey();
					Object modelValue = entry.getValue();
					if (modelValue != null) {
						request.setAttribute(modelName, modelValue);
					} else {
						request.removeAttribute(modelName);
					}
				}
			}
		}

		super.onRender(content, definition, renderingCtx, ctx, templateScript);
	}
}