package com.triabeauty.module.controllers;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
public class ExternalController {

    @RequestMapping("/external1")
    @ResponseBody
    public String external() {
        return qwe();
    }

    @RequestMapping("/external2")
    @ResponseBody
    public String external2025() {
        return "123456";
    }

    @RequestMapping("/external33")
    @ResponseBody
    public String external3() {
        return "3333";
    }

    private String qwe() {
        return "This is an externally accessible controller 123456";
    }

}
