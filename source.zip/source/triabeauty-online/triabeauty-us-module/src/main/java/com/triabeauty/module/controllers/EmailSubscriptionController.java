/** 
 * Copyright (c) 2009 TRIA Beauty INC. All Rights Reserved.
 *
 * This software is the confidential and proprietary information of TRIA
 * Beauty INC ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the terms
 * of the license agreement you entered into with TRIA Beauty INC.
 *
 * TRIA Beauty INC MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY OF 
 * SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
 * PURPOSE, OR NON-INFRINGEMENT. TRIA Beauty INC SHALL NOT BE LIABLE FOR ANY
 * DAMAGES SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 **/

/**
 *FileName:LogoutController.java
 *
 *
 *@author 
 *Created By: rmoluguri
 *Reviewed By : <Name of person >
 *
 *@Creation Date: 
 *@Last Modified Date: 
 *
 *@version History
 *@<history goes here>
 *Update By <User Name> on <Date of modification> for <Reason for modification>  *
 **/

package com.triabeauty.module.controllers;

import java.io.PrintWriter;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.triabeauty.enterprise.entities.transactional.vo.EmailSubscription;
import com.triabeauty.enterprise.service.endpoint.remote.CustomerServiceRemote;
import com.triabeauty.enterprise.service.locator.ServiceLocator;

/**
 * @author smtagirisa
 * 
 */
@Controller
public class EmailSubscriptionController {
	private static final Logger LOG = Logger
			.getLogger(EmailSubscriptionController.class.getName());

	@RequestMapping("/subscribe")
	@ResponseBody
	protected ModelAndView handleRequestInternal(
			final HttpServletRequest request, final HttpServletResponse response)
			throws Exception {
		if (LOG.isDebugEnabled()) {
			LOG.debug("EmailSubscriptionController handleRequestInternal method - entry");
		}
		boolean result = false;
		final String emailId = request.getParameter("email");
		// Adding first Name for email subscription
		String firstName = request.getParameter("firstName");
		final String source = request.getParameter("source");
		final PrintWriter pw = response.getWriter();
		if (emailId == null || emailId.trim().length() == 0) {
			pw.write("NO");
			pw.close();
			return null;
		}

		try {
			CustomerServiceRemote customerService = (CustomerServiceRemote) ServiceLocator
					.lookUp(CustomerServiceRemote.class);

			EmailSubscription subscriptionData = new EmailSubscription();
			subscriptionData.setEmail(emailId);
			subscriptionData.setFirstName(firstName);
			subscriptionData.setSourceValue(source);
			customerService.activateEmailSubscription(subscriptionData);
			if (result) {

				LOG.info("Email is subscirbed for the preferences");

				pw.write("OK");
			} else {
				pw.write("NO");
			}

		} catch (final Exception e) {
			LOG.error("Exception while subscribing for Emails: "
					+ e.getMessage());
			pw.write("NO");
		} finally {
			pw.close();
		}

		if (LOG.isDebugEnabled()) {
			LOG.debug("EmailSubscriptionController handleRequestInternal method - exit");
		}
		return null;
	}

}
