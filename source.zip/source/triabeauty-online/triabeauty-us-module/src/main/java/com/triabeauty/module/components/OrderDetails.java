/** 
 * Copyright (c) 2009 TRIA Beauty INC. All Rights Reserved.
 *
 * This software is the confidential and proprietary information of TRIA
 * Beauty INC ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the terms
 * of the license agreement you entered into with TRIA Beauty INC.
 *
 * TRIA Beauty INC MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY OF 
 * SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
 * PURPOSE, OR NON-INFRINGEMENT. TRIA Beauty INC SHALL NOT BE LIABLE FOR ANY
 * DAMAGES SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 **/

/**
 *FileName:orderReview.java
 *
 *
 *@author 
 *Created By: 
 *Reviewed By : Sivaramakrishna
 *
 *@Creation Date: ${date}
 *@Last Modified Date: <last modified date>
 *
 *@version History
 *@<history goes here>
 *Update By <User Name> on <Date of modification> for <Reason for modification>  *
 **/

package com.triabeauty.module.components;


import info.magnolia.module.blossom.annotation.TabFactory;
import info.magnolia.module.blossom.annotation.Template;
import info.magnolia.module.blossom.dialog.TabBuilder;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

/**
 * Renders the contents of the shopping cart in a small summarized format.
 */
@Controller
@Template(title = "OrderDetails", id = "tria-us-cms-module:components/orderDetails")
public class OrderDetails {

	private static final Logger log = LoggerFactory
			.getLogger(OrderDetails.class);

	@RequestMapping(value = "/orderDetails", method = RequestMethod.GET)
	public String render(ModelMap model, HttpSession session, HttpServletRequest request) {
		log.warn("*****Order Details Render*******");
		
		model.addAttribute("order", request.getSession().getAttribute("order"));
		model.addAttribute("easyPay", session.getAttribute("easyPay"));
		model.addAttribute("easyPayProducts", session.getAttribute("easyPayProducts"));
		model.addAttribute("replenishProduct", session.getAttribute("replenishProduct"));
		session.removeAttribute("easyPay");
		session.removeAttribute("easyPayProducts");
		session.removeAttribute("replenishProduct");
		log.warn("*****Order Details Render end*******");
		return "components/orderDetails.ftl";
	}

	@TabFactory("Content")
	public void contentTab(TabBuilder tab) {
		tab.addStatic("This component requires no cofiguration");
		tab.addHidden("bogus", "value");
	}



}