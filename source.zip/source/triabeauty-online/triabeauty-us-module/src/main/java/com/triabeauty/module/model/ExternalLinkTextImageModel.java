/**
 * This file Copyright (c) 2009-2011 Magnolia International
 * Ltd.  (http://www.magnolia-cms.com). All rights reserved.
 *
 *
 * This file is dual-licensed under both the Magnolia
 * Network Agreement and the GNU General Public License.
 * You may elect to use one or the other of these licenses.
 *
 * This file is distributed in the hope that it will be
 * useful, but AS-IS and WITHOUT ANY WARRANTY; without even the
 * implied warranty of MERCHANTABILITY or FITNESS FOR A
 * PARTICULAR PURPOSE, TITLE, or NONINFRINGEMENT.
 * Redistribution, except as permitted by whichever of the GPL
 * or MNA you select, is prohibited.
 *
 * 1. For the GPL license (GPL), you can redistribute and/or
 * modify this file under the terms of the GNU General
 * Public License, Version 3, as published by the Free Software
 * Foundation.  You should have received a copy of the GNU
 * General Public License, Version 3 along with this program;
 * if not, write to the Free Software Foundation, Inc., 51
 * Franklin St, Fifth Floor, Boston, MA 02110-1301 USA.
 *
 * 2. For the Magnolia Network Agreement (MNA), this file
 * and the accompanying materials are made available under the
 * terms of the MNA which accompanies this distribution, and
 * is available at http://www.magnolia-cms.com/mna.html
 *
 * Any modifications to this file must keep this entire header
 * intact.
 *
 */
package com.triabeauty.module.model;

import info.magnolia.jcr.util.PropertyUtil;
import info.magnolia.module.templatingkit.functions.STKTemplatingFunctions;
import info.magnolia.module.templatingkit.style.CssSelectorBuilder;
import info.magnolia.module.templatingkit.templates.components.ImageModel;
import info.magnolia.rendering.model.RenderingModel;
import info.magnolia.rendering.template.TemplateDefinition;
import info.magnolia.templating.functions.TemplatingFunctions;

import javax.inject.Inject;
import javax.jcr.Node;


/**
 * Text Image STK Rendable definition.
 * As Text Image are linked to Images...., this class extend the Rendable Image.
 * @author pbracher
 * @version $Id: TextImageModel.java 53081 2012-01-03 08:01:22Z ehechinger $
 * @param <RD>
 */
public class ExternalLinkTextImageModel<RD extends TemplateDefinition>  extends ImageModel<TemplateDefinition> {

    @Inject
    public ExternalLinkTextImageModel(Node content, RD definition, RenderingModel< ? > parent, STKTemplatingFunctions stkFunctions, CssSelectorBuilder cssSelectorBuilder, TemplatingFunctions templatingFunctions) {
        super(content, definition, parent, stkFunctions, cssSelectorBuilder, templatingFunctions);
    }

    @Override
    protected String getImageName() {
        return super.getImageName();
    }

    @Override
    public String getImageClass() {
        String imageLocation = PropertyUtil.getString(content, "imageLocation", "left");
        if(imageLocation.equals("left")){
            return "media photo";
        }
        else if(imageLocation.equals("right")){
            return "media photo pos-2";
        }
        else if(imageLocation.equals("above")){
            return "media photo large";
        }
        else{
            return null;
        }
    }
    public String getLink(){
        return templatingFunctions.externalLink(content, "link");
    }

    public String getLinkTitle(){
        return templatingFunctions.externalLinkTitle(content, "link", "linkTitle");
    }
}
