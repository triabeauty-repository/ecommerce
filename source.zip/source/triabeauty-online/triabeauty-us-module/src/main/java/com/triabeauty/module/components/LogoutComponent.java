package com.triabeauty.module.components;

import info.magnolia.module.blossom.annotation.TabFactory;
import info.magnolia.module.blossom.annotation.Template;
import info.magnolia.module.blossom.annotation.TemplateDescription;
import info.magnolia.module.blossom.dialog.TabBuilder;
import info.magnolia.module.blossom.view.UuidRedirectView;

import javax.jcr.Node;
import javax.jcr.RepositoryException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

@Controller
@Template(title = "logout", id = "tria-us-cms-module:components/logout", visible = true)
@TemplateDescription(value = "logout")
public class LogoutComponent {

	private static final Logger log = LoggerFactory
			.getLogger(LogoutComponent.class);

	@RequestMapping("/logout")
	public ModelAndView handleRequest(
			Node content, HttpServletRequest request, ModelMap model)
					throws RepositoryException{

		log.warn("*********logout start****************");

		HttpSession httpSession = null;
		try
		{
			request.getSession().removeAttribute("User");
			request.getSession().invalidate();
			log.info("User Successfully Signed Off.");
		}
		catch (final Exception e)
		{
			model.addAttribute("ERROR_MESSAGE", "could not logout");
			log.error("could not logout" + e.getMessage());

		}
		finally
		{
			try
			{
				if (httpSession != null)
				{
					httpSession.invalidate();
				}
			}
			catch (final Exception e)
			{
				log.error(e.getMessage());
			}
		}
		return new ModelAndView(new UuidRedirectView("website", content
				.getProperty("successPage").getString()));
	}

	@TabFactory("logout Form")
	public void contentTab(TabBuilder tab) {
		tab.addUuidLink("successPage", "Success page", "");

	}
}
