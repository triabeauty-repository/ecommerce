package com.triabeauty.module.components;

import info.magnolia.module.blossom.annotation.TabFactory;
import info.magnolia.module.blossom.annotation.Template;
import info.magnolia.module.blossom.annotation.TemplateDescription;
import info.magnolia.module.blossom.dialog.TabBuilder;

import java.util.ArrayList;
import java.util.List;

import javax.jcr.Node;
import javax.jcr.RepositoryException;
import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.triabeauty.enterprise.entities.transactional.vo.Address;
import com.triabeauty.enterprise.entities.transactional.vo.User;
import com.triabeauty.enterprise.service.constants.AddressType;
import com.triabeauty.enterprise.service.constants.Country;
import com.triabeauty.enterprise.service.constants.Region;
import com.triabeauty.enterprise.service.constants.StateCode;
import com.triabeauty.enterprise.service.endpoint.remote.CartServiceRemote;
import com.triabeauty.enterprise.service.endpoint.remote.CustomerServiceRemote;
import com.triabeauty.enterprise.service.locator.Remote;
import com.triabeauty.enterprise.service.locator.ServiceLocator;
import com.triabeauty.module.beans.AddressBookForm;

@Controller
@Template(title = "AddressBook", id = "tria-us-cms-module:components/addressBook", visible = true)
@TemplateDescription(value = "AddressBook Form ")
public class AddressBookComponent {

	private static final Logger log = LoggerFactory
			.getLogger(AddressBookComponent.class);

	@RequestMapping(value = "/addressBook", method = RequestMethod.GET)
	public String render(
			@ModelAttribute("addressBookForm") AddressBookForm addressBookForm,
			BindingResult result, Node content, HttpServletRequest request,
			ModelMap model) {
		log.warn("***********AddressBook Render**************");

		User user = (User) request.getAttribute("user");

		if (user != null) {
			addressBookForm = prepareAddressBookForm(user, addressBookForm);
		}
		model.addAttribute("addressBookForm", addressBookForm);
		model.addAttribute("states", getStates());
		return "components/addressBookForm.ftl";
	}

	@RequestMapping(value = "/addressBook", method = RequestMethod.POST)
	public String submit(
			@ModelAttribute("addressBookForm") AddressBookForm addressBookForm,
			BindingResult result, Node content, HttpServletRequest request,
			ModelMap model) throws RepositoryException {
		log.warn("***********AddressBook Submit**************");
		log.warn("AddressBookForm :" + addressBookForm.toString());

		try {
			User user = null;
			CustomerServiceRemote customerService = (CustomerServiceRemote) ServiceLocator
					.lookUp(CustomerServiceRemote.class);
			Address shippingAddress = new Address();
			Address billingAddress = new Address();
			String country="US";
			if(addressBookForm.getCountry().equalsIgnoreCase("CAN"))
			{
				country="CA";
			}
			shippingAddress.setAddressType(AddressType.SHIPPING);
			shippingAddress
					.setFirstName(addressBookForm.getShippingFirstName());
			shippingAddress.setLastName(addressBookForm.getShippingLastName());
			shippingAddress.setAddressLine1(addressBookForm
					.getShippingAddress1());
			shippingAddress.setAddressLine2(addressBookForm
					.getShippingAddress2());
			shippingAddress.setCity(addressBookForm.getShippingCity());
			shippingAddress.setCountry(Country.valueOf(country));
			shippingAddress.setStateCode(addressBookForm.getShippingState());
			shippingAddress.setRegion(Region.NORTH_AMERICAN);
			shippingAddress.setZip(addressBookForm.getShippingZip());
			shippingAddress.setPhoneNumber1(addressBookForm.getShippingPhone());

			billingAddress.setAddressType(AddressType.BILLING);
			billingAddress.setFirstName(addressBookForm.getBillingFirstName());
			billingAddress.setLastName(addressBookForm.getBillingLastName());
			billingAddress
					.setAddressLine1(addressBookForm.getBillingAddress1());
			billingAddress
					.setAddressLine2(addressBookForm.getBillingAddress2());
			billingAddress.setCity(addressBookForm.getBillingCity());
			billingAddress.setCountry(Country.valueOf(country));
			billingAddress.setStateCode(addressBookForm.getBillingState());
			billingAddress.setRegion(Region.NORTH_AMERICAN);
			billingAddress.setZip(addressBookForm.getBillingZip());
			billingAddress.setPhoneNumber1(addressBookForm.getBillingPhone());

			log.warn("User :" + request.getSession().getAttribute("user"));
			if (request.getSession().getAttribute("user") != null) {
				user = (User) request.getSession().getAttribute("user");
				user.setShippingAddress(shippingAddress);
				user.setBillingAddress(billingAddress);
			}

			try {
				user = customerService.updateCustomerAddressDetails(user);
				model.addAttribute("SUCCESS_MESSAGE",
						"Address updated successfully.");

			} catch (Exception e) {
				log.error("Exception occured while updating the shippping and billing address: "
						+ e.getMessage());
				model.addAttribute("ERROR_MESSAGE", "Address is not updated");
			}

			CartServiceRemote cartService = Remote.getCartSerice(request);
			cartService.setShippingAddress(shippingAddress);
			cartService.setBillingAddress(billingAddress);
			cartService.setEmail(user.getEmail());
			request.getSession().setAttribute("user", user);
			log.warn("***********AddressBook End**************");
		} catch (Exception e) {
			e.printStackTrace();
		}

		return "components/addressBookForm.ftl";
	}

	AddressBookForm prepareAddressBookForm(User user,
			AddressBookForm addressBookForm) {
		Address shippingAddress = user.getShippingAddress();
		Address billingAddress = user.getShippingAddress();
		log.warn("shippingAddress: " + shippingAddress);
		log.warn("billingAddress: " + shippingAddress);
		String country="USA";
		
		if (shippingAddress != null) {
			if(shippingAddress.getCountry().getCode().equalsIgnoreCase("CA"))
			{
				country="CAN";
			}
			addressBookForm
					.setShippingFirstName(shippingAddress.getFirstName());
			addressBookForm.setShippingLastName(shippingAddress.getLastName());
			addressBookForm.setShippingAddress1(shippingAddress
					.getAddressLine1());
			addressBookForm.setShippingAddress2(shippingAddress
					.getAddressLine2());
			addressBookForm.setShippingCity(shippingAddress.getCity());
			addressBookForm.setShippingState(shippingAddress.getStateCode());
			addressBookForm.setCountry(country);
			addressBookForm.setShippingZip(shippingAddress.getZip());
			addressBookForm.setShippingPhone(shippingAddress.getPhoneNumber1());
		}
		if (billingAddress != null) {
			addressBookForm.setBillingFirstName(billingAddress.getFirstName());
			addressBookForm.setBillingLastName(billingAddress.getLastName());
			addressBookForm
					.setBillingAddress1(billingAddress.getAddressLine1());
			addressBookForm
					.setBillingAddress2(billingAddress.getAddressLine2());
			addressBookForm.setBillingCity(billingAddress.getCity());
			addressBookForm.setBillingState(billingAddress.getStateCode());
			addressBookForm.setBillingZip(billingAddress.getZip());
			addressBookForm.setBillingPhone(billingAddress.getPhoneNumber1());
		}
		return addressBookForm;
	}

	@TabFactory("AddressBook Form")
	public void contentTab(TabBuilder tab) {
		tab.addUuidLink("successPage", "Success page", "");
		tab.addUuidLink("logInPage", "LogIn page", "");
	}

	private List<String> getStates() {

		List<String> states = new ArrayList<String>();

		for (StateCode s : StateCode.values()) {

			states.add(s.getCode());
		}

		return states;
	}

}
