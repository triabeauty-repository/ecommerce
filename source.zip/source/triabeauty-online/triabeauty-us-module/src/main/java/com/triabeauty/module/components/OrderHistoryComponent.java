package com.triabeauty.module.components;

import info.magnolia.module.blossom.annotation.TabFactory;
import info.magnolia.module.blossom.annotation.Template;
import info.magnolia.module.blossom.annotation.TemplateDescription;
import info.magnolia.module.blossom.dialog.TabBuilder;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.triabeauty.enterprise.entities.transactional.vo.Order;
import com.triabeauty.enterprise.entities.transactional.vo.User;
import com.triabeauty.enterprise.service.endpoint.remote.OrderServiceRemote;
import com.triabeauty.enterprise.service.locator.ServiceLocator;

@Controller
@Template(title = "orderHistory", id = "tria-us-cms-module:components/orderHistory", visible = true)
@TemplateDescription(value = "Order History")
public class OrderHistoryComponent {

	private static final Logger log = LoggerFactory
			.getLogger(OrderHistoryComponent.class);

	@SuppressWarnings("unchecked")
	@RequestMapping(value = "/orderHistory", method = RequestMethod.GET)
	public String render(HttpServletRequest request, ModelMap model) {
		log.warn("***********orderHistory Render start**************");
		String orderNumber=request.getParameter("orderNumber");
		log.warn("orderNumber: "+orderNumber);
		if(orderNumber==null)
		{
			User user=(User)request.getSession().getAttribute("user");
			OrderServiceRemote orderService = (OrderServiceRemote) ServiceLocator
					.lookUp(OrderServiceRemote.class);
			List<Order> orders=null;
			if(user!=null)
			{
				try {
					orders=orderService.getOrders(user.getEmail());
					if(orders!=null)
					{
						log.warn("Orders Placed:"+orders.size());
					}
					model.addAttribute("orderHistoryList", orders);
					request.getSession().setAttribute("orders", orders);
				} catch (Exception e) {
					e.printStackTrace();
					log.error("Exception while retrieving order history:"+e.getMessage());
				}
			}
		}else
		{
			List<Order> orders=(List<Order>) request.getSession().getAttribute("orders");
			for(Order order:orders)
			{
				if(order.getOrderNumber().equals(orderNumber))
				{
					log.warn("Orders Matched:"+orderNumber);
					model.addAttribute("order", order);
					break;
				}
			}
		}
		log.warn("***********orderHistory Render end**************");
		return "components/orderHistory.ftl";
	}

	@TabFactory("orderHistory")
	public void contentTab(TabBuilder tab) {
		tab.addStatic("This component requires no configuration");
		tab.addHidden("hidden", "value");
	}


}
