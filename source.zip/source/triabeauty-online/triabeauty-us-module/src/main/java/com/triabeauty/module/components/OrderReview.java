/** 
 * Copyright (c) 2009 TRIA Beauty INC. All Rights Reserved.
 *
 * This software is the confidential and proprietary information of TRIA
 * Beauty INC ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the terms
 * of the license agreement you entered into with TRIA Beauty INC.
 *
 * TRIA Beauty INC MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY OF 
 * SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
 * PURPOSE, OR NON-INFRINGEMENT. TRIA Beauty INC SHALL NOT BE LIABLE FOR ANY
 * DAMAGES SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 **/

/**
 *FileName:orderReview.java
 *
 *
 *@author 
 *Created By: 
 *Reviewed By : Sivaramakrishna
 *
 *@Creation Date: ${date}
 *@Last Modified Date: <last modified date>
 *
 *@version History
 *@<history goes here>
 *Update By <User Name> on <Date of modification> for <Reason for modification>  *
 **/

package com.triabeauty.module.components;

import info.magnolia.module.blossom.annotation.TabFactory;
import info.magnolia.module.blossom.annotation.Template;
import info.magnolia.module.blossom.dialog.TabBuilder;
import info.magnolia.module.blossom.view.UuidRedirectView;

import javax.jcr.Node;
import javax.jcr.RepositoryException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.triabeauty.enterprise.entities.transactional.vo.Address;
import com.triabeauty.enterprise.entities.transactional.vo.Cart;
import com.triabeauty.enterprise.entities.transactional.vo.CreditCardDetails;
import com.triabeauty.enterprise.entities.transactional.vo.Order;
import com.triabeauty.enterprise.service.constants.AddressType;
import com.triabeauty.enterprise.service.constants.CardType;
import com.triabeauty.enterprise.service.constants.Country;
import com.triabeauty.enterprise.service.constants.Region;
import com.triabeauty.enterprise.service.endpoint.remote.CartServiceRemote;
import com.triabeauty.enterprise.service.locator.Remote;
import com.triabeauty.module.beans.PaymentServiceForm;
import com.triabeauty.module.utilities.PaymentUtil;
import com.triabeauty.module.utilities.ShippingMethodUtil;

/**
 * Renders the contents of the shopping cart in a small summarized format.
 */
@Controller
@Template(title = "OrderReview", id = "tria-us-cms-module:components/orderReview")
public class OrderReview {

	private static final Logger log = LoggerFactory
			.getLogger(OrderReview.class);

	@RequestMapping(value = "/orderReview", method = RequestMethod.GET)
	public String render(@ModelAttribute PaymentServiceForm paymentServiceForm,
			ModelMap model, HttpSession session, HttpServletRequest request) {
		log.warn("*****Order Review Render*******");
		CartServiceRemote cartService = Remote.getCartSerice(request);
		try {
			Cart cart = cartService.getSessionCart();

			model.put("cart", cartService.getSessionCart());

			paymentServiceForm = preparePaymentServiceForm(cart,
					paymentServiceForm, cartService.getCardDetails());
			model.addAttribute("paymentServiceForm", paymentServiceForm);
			model.addAttribute("shippingMethods",
					ShippingMethodUtil.getShippingMethods(request,cart.getCountry()));
			model.addAttribute("cardTypes", PaymentUtil.getCardTypes());
			model.addAttribute("months", PaymentUtil.getExpiryDateMonth());
			model.addAttribute("years", PaymentUtil.getExpiryDateYear());
			model.addAttribute("easyPay", session.getAttribute("easyPay"));
			model.addAttribute("easyPayProducts", session.getAttribute("easyPayProducts"));
			model.addAttribute("replenishProduct", session.getAttribute("replenishProduct"));
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		log.warn("*****Order Review Render end*******");
		return "components/orderReview.ftl";
	}

	@TabFactory("Content")
	public void contentTab(TabBuilder tab) {
		tab.addUuidLink("successPage", "Success page", "");
	}

	@RequestMapping(value = "/orderReview", method = RequestMethod.POST)
	public ModelAndView submit(
			@ModelAttribute PaymentServiceForm paymentServiceForm,
			BindingResult result, ModelMap model, Node content,
			HttpServletRequest request) throws RepositoryException {
		log.warn("*****Order Review Submit*******");

		CartServiceRemote cartService = Remote.getCartSerice(request);
		log.warn("action: " + request.getParameter("action"));
		log.warn("PaymentServiceForm: " + paymentServiceForm.toString());
		if ("editShippingAddress".equals(request.getParameter("action"))) {
			editShippingAddress(paymentServiceForm, request);
			return new ModelAndView("redirect:" + request.getRequestURL());
		} else if ("editBillingAddress".equals(request.getParameter("action"))) {
			editBillingAddress(paymentServiceForm, request);
			return new ModelAndView("redirect:" + request.getRequestURL());
		} else if ("editPaymentInfo".equals(request.getParameter("action"))) {
			editPaymentInfo(paymentServiceForm, request);
			return new ModelAndView("redirect:" + request.getRequestURL());
		} else if ("editShippingMethod".equals(request.getParameter("action"))) {
			editShippingMethod(paymentServiceForm, request);
			return new ModelAndView("redirect:" + request.getRequestURL());
		} else {
			try {
				Order order = cartService.placeOrder();
				request.getSession().setAttribute("order", order);
			} catch (Exception e) {
				e.printStackTrace();
				model.addAttribute("ERROR_MSG","Experiencing difficulities while placing an order, Please try again..");
				return new ModelAndView("components/orderReview.ftl");
			}
			log.warn("*****Order Review End*******");
			return new ModelAndView(new UuidRedirectView("website", content
					.getProperty("successPage").getString()));
		}
	}

	private void editShippingAddress(PaymentServiceForm paymentServiceForm,
			HttpServletRequest request) {

		log.warn("*****OrderReview editShippingAddress start*******");
		CartServiceRemote cartService = Remote.getCartSerice(request);

		Address shippingAddress = new Address();
		shippingAddress.setAddressType(AddressType.SHIPPING);
		shippingAddress.setFirstName(paymentServiceForm.getShippingFirstName());
		shippingAddress.setLastName(paymentServiceForm.getShippingLastName());
		shippingAddress.setAddressLine1(paymentServiceForm
				.getShippingAddress1());
		shippingAddress.setAddressLine2(paymentServiceForm
				.getShippingAddress2());
		shippingAddress.setCity(paymentServiceForm.getShippingCity());
		shippingAddress.setCountry(Country.valueOf("US"));
		shippingAddress.setStateCode(paymentServiceForm.getShippingState());
		shippingAddress.setRegion(Region.NORTH_AMERICAN);
		shippingAddress.setZip(paymentServiceForm.getShippingZip());
		shippingAddress.setPhoneNumber1(paymentServiceForm.getShippingPhone1()
				+ "-" + paymentServiceForm.getShippingPhone2() + "-"
				+ paymentServiceForm.getShippingPhone3());

		cartService.setShippingAddress(shippingAddress);
		log.warn("*****OrderReview editShippingAddress end*******");
	}

	private void editBillingAddress(PaymentServiceForm paymentServiceForm,
			HttpServletRequest request) {

		log.warn("*****editBillingAddress start*******");
		CartServiceRemote cartService = Remote.getCartSerice(request);

		Address billingAddress = new Address();
		billingAddress.setAddressType(AddressType.BILLING);
		billingAddress.setFirstName(paymentServiceForm.getBillingFirstName());
		billingAddress.setLastName(paymentServiceForm.getBillingLastName());
		billingAddress.setAddressLine1(paymentServiceForm.getBillingAddress1());
		billingAddress.setAddressLine2(paymentServiceForm.getBillingAddress2());
		billingAddress.setCity(paymentServiceForm.getBillingCity());
		billingAddress.setCountry(Country.valueOf("US"));
		billingAddress.setStateCode(paymentServiceForm
				.getBillingState());
		billingAddress.setRegion(Region.NORTH_AMERICAN);
		billingAddress.setZip(paymentServiceForm.getBillingZip());
		billingAddress.setPhoneNumber1(paymentServiceForm.getBillingPhone1()
				+ "-" + paymentServiceForm.getBillingPhone2() + "-"
				+ paymentServiceForm.getBillingPhone3());

		cartService.setBillingAddress(billingAddress);
		log.warn("*****editBillingAddress end*******");
	}

	private void editPaymentInfo(PaymentServiceForm paymentServiceForm,
			HttpServletRequest request) {

		log.warn("*****editPaymentInfo start*******");
		CartServiceRemote cartService = Remote.getCartSerice(request);
		try {

			CreditCardDetails cardDetails = new CreditCardDetails();
			cardDetails.setCardNumber(paymentServiceForm.getCreditCardNumber());
			cardDetails.setCvv(paymentServiceForm.getCvv());
			cardDetails.setCardType(CardType.valueOf(paymentServiceForm
					.getCardType()));
			cardDetails.setExpiryMonth(paymentServiceForm.getExpiryDateMonth());
			cardDetails.setExpiryYear(paymentServiceForm.getExpiryDateYear());

			cartService.setCardDetails(cardDetails);
		} catch (Exception e) {
			e.printStackTrace();
		}
		log.warn("*****editPaymentInfo end*******");
	}

	private void editShippingMethod(PaymentServiceForm paymentServiceForm,
			HttpServletRequest request) {

		log.warn("*****editShippingMethod start*******");
		CartServiceRemote cartService = Remote.getCartSerice(request);
		cartService
				.changeShippingMethod(paymentServiceForm.getShippingMethod());
		log.warn("*****editShippingMethod end*******");
	}

	PaymentServiceForm preparePaymentServiceForm(Cart cart,
			PaymentServiceForm paymentServiceForm, CreditCardDetails cardDetails) {
		Address shippingAddress = cart.getShippingAddress();
		Address billingAddress = cart.getBillingAddress();
		log.warn("shippingAddress: " + shippingAddress);
		log.warn("billingAddress: " + shippingAddress);
		paymentServiceForm.setEmail(cart.getEmail());
		if (shippingAddress != null) {
			paymentServiceForm.setShippingFirstName(shippingAddress
					.getFirstName());
			paymentServiceForm.setShippingLastName(shippingAddress
					.getLastName());
			paymentServiceForm.setShippingAddress1(shippingAddress
					.getAddressLine1());
			paymentServiceForm.setShippingAddress2(shippingAddress
					.getAddressLine2());
			paymentServiceForm.setShippingCity(shippingAddress.getCity());
			paymentServiceForm.setShippingState(shippingAddress.getStateCode());
			paymentServiceForm.setShippingZip(shippingAddress.getZip());
			paymentServiceForm.setShippingPhone(shippingAddress
					.getPhoneNumber1());
			paymentServiceForm.setShippingCountry(shippingAddress.getCountry()
					.getCode());
		}
		if (billingAddress != null) {
			paymentServiceForm.setBillingFirstName(billingAddress
					.getFirstName());
			paymentServiceForm.setBillingLastName(billingAddress.getLastName());
			paymentServiceForm.setBillingAddress1(billingAddress
					.getAddressLine1());
			paymentServiceForm.setBillingAddress2(billingAddress
					.getAddressLine2());
			paymentServiceForm.setBillingCity(billingAddress.getCity());
			paymentServiceForm.setBillingState(billingAddress.getStateCode());
			paymentServiceForm.setBillingZip(billingAddress.getZip());
			paymentServiceForm
					.setBillingPhone(billingAddress.getPhoneNumber1());
		}
		if (cardDetails != null) {
			paymentServiceForm.setCardType(cardDetails.getCardType().toString());
			paymentServiceForm.setCreditCardNumber(cardDetails.getCardNumber());
			paymentServiceForm.setExpiryDateMonth(cardDetails.getExpiryMonth());
			paymentServiceForm.setExpiryDateYear(cardDetails.getExpiryYear());
			paymentServiceForm.setCvv(cardDetails.getCvv());
		}
		if (cart.getShippingCompanyService() != null) {
			paymentServiceForm.setShippingMethod(cart
					.getShippingCompanyService().getServiceTitle());
		}
		return paymentServiceForm;
	}


}