package com.triabeauty.module.components;

import info.magnolia.module.blossom.annotation.TabFactory;
import info.magnolia.module.blossom.annotation.Template;
import info.magnolia.module.blossom.annotation.TemplateDescription;
import info.magnolia.module.blossom.dialog.TabBuilder;

import javax.jcr.RepositoryException;
import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.triabeauty.enterprise.entities.transactional.vo.User;
import com.triabeauty.enterprise.service.endpoint.remote.CustomerServiceRemote;
import com.triabeauty.enterprise.service.locator.ServiceLocator;

@Controller
@Template(title = "emailPasswordPreferences", id = "tria-us-cms-module:components/emailPasswordPreferences", visible = true)
@TemplateDescription(value = "emailPasswordPreferences Form ")
public class EmailPasswordPreferencesComponent {

	private static final Logger log = LoggerFactory
			.getLogger(EmailPasswordPreferencesComponent.class);

	@RequestMapping(value = "/emailPasswordPreferences", method = RequestMethod.GET)
	public String render(HttpServletRequest request, ModelMap model) {
		log.warn("***********emailPasswordPreferences Render**************");

		User user = (User) request.getAttribute("user");
		model.addAttribute("user", user);
		return "components/emailPasswordPreferences.ftl";
	}

	@RequestMapping(value = "/emailPasswordPreferences", method = RequestMethod.POST)
	public String submit(HttpServletRequest request, ModelMap model)
			throws RepositoryException {
		log.warn("***********emailPasswordPreferences Submit**************");
		log.warn("action: " + request.getParameter("action"));
		User user = (User) request.getSession().getAttribute("user");
		int flag = 0;
		try {
			if ("changeEmail".equals(request.getParameter("action"))) {
				flag=changeEmail(request,user);
				if(flag>0)
				{
					model.addAttribute("SUCCESS_MESSAGE", "Email changed successfully.");
				}else
				{
					model.addAttribute("ERROR_MESSAGE", "Email is not changed");
				}
			}else if ("changeEmailSignUp".equals(request.getParameter("action"))) {
				user=changeEmailSubsription(request,user);
			}else if ("changePassword".equals(request.getParameter("action"))) {
				flag=changePassword(request,user);
				log.warn("ChangePassword update flag: "+flag);
				if(flag>0)
				{
					model.addAttribute("successMsg", "Password changed successfully.");
				}else
				{
					model.addAttribute("errMsg", "Password is not changed");
				}
			}

			log.warn("***********emailPasswordPreferences End**************");

		} catch (Exception e) {
			e.printStackTrace();
		}

		model.addAttribute("user", user);
		request.getSession().setAttribute("user", user);
		return "components/emailPasswordPreferences.ftl";
	}

	@TabFactory("Email & Password Preferences Form")
	public void contentTab(TabBuilder tab) {
		tab.addStatic("This component requires no configuration");
		tab.addHidden("bogus", "bogus");

	}

	private Integer changeEmail(HttpServletRequest request, User user) 
	{

		log.warn("*****emailPasswordPreferences ChangeEmail Start*******");

		String newEmail=request.getParameter("newEmail");
		int flag=0;
		log.warn("newEmail: "+newEmail);
		CustomerServiceRemote customerService = (CustomerServiceRemote) ServiceLocator
				.lookUp(CustomerServiceRemote.class);

		user.setEmail(newEmail);

		try {
			flag= customerService.changeEmailAddress(user.getCustomerID(), newEmail);
			if(flag>0)
			{
				request.getSession().setAttribute("user", user);
			}
		} catch (Exception e) {
			e.printStackTrace();
			log.error("Exception occured while changing an email: "
					+ e.getMessage());
		}
		return flag;
	}

	private User changeEmailSubsription(HttpServletRequest request, User user) 
	{

		log.warn("*****emailPasswordPreferences changeEmailSubsription Start*******");

		String emailPreference=request.getParameter("emailPreference");
		log.warn("emailPreference: "+emailPreference);
		CustomerServiceRemote customerService = (CustomerServiceRemote) ServiceLocator
				.lookUp(CustomerServiceRemote.class);
		boolean flag=false;
		try {
			flag=customerService.changeSubscriptionPreference(user.getEmail(), Boolean.valueOf(emailPreference));
			if(flag)
			{
				user.setSubscribedToNewsLetter(Boolean.valueOf(emailPreference));
				request.getSession().setAttribute("user", user);
			}
		} catch (Exception e) {
			e.printStackTrace();
			log.error("Exception occured while updating Email Subscription: "
					+ e.getMessage());
		}

		return user;
	}

	private int changePassword(HttpServletRequest request,User user) 
	{

		log.warn("*****emailPasswordPreferences changePassword Start*******");
		log.warn("email: "+user.getEmail());

		String oldPassword=request.getParameter("oldPassword");
		String updatePassword=request.getParameter("password");

		log.warn("oldPassword: "+oldPassword);
		CustomerServiceRemote customerService = (CustomerServiceRemote) ServiceLocator
				.lookUp(CustomerServiceRemote.class);

		try {
			return customerService.updatePassword(user.getEmail(),updatePassword);
		} catch (Exception e) {
			e.printStackTrace();
			log.error("Exception occured while changing password: "
					+ e.getMessage());
			return 0;
		}
	}
}
