package com.triabeauty.module.components;
import info.magnolia.cms.gui.dialog.Dialog;
import info.magnolia.cms.gui.dialog.DialogTab;
import info.magnolia.module.admininterface.DialogHandlerManager;
import info.magnolia.module.admininterface.DialogMVCHandler;
import info.magnolia.module.blossom.annotation.DialogFactory;
import info.magnolia.module.blossom.annotation.TabFactory;
import info.magnolia.module.blossom.dialog.DialogCreationContext;
import info.magnolia.module.blossom.dialog.TabBuilder;

@DialogFactory("triaExtendedExternalLink")
public class ExtendingDialogFactory {

    @TabFactory("something")
    public void something(DialogCreationContext dialogCreationContext) {

        // Get the configured dialog
        DialogMVCHandler dialogHandler = DialogHandlerManager.getInstance().getDialogHandler(
                "standard-templating-kit:components/links/stkExternalLink",
                dialogCreationContext.getRequest(),
                dialogCreationContext.getResponse());
        System.out.println("dialoghandler: "+dialogHandler);
        Dialog dialog = dialogHandler.getDialog();
        System.out.println("dialog: "+dialog);
        System.out.println(dialog.getId());
        // Replace the dialog created by Blossom, this removes support for Blossom style validation callbacks
        dialogCreationContext.setDialog(dialog);

      /*  // Adding a new tab
        DialogBuilder dialogBuilder = new DialogBuilder(dialogCreationContext);
        TabBuilder newTab = dialogBuilder.addTab("Image");
        newTab.addFile("image", "Image", "");*/

        // Adding to an existing tab
        TabBuilder existingTab = new TabBuilder(dialogCreationContext, (DialogTab) dialog.getSub("tabInternalLink"));
        existingTab.addFile("image", "Image", "");
    }
}
