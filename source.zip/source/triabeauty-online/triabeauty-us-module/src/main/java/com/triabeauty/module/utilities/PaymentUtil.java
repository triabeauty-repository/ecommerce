package com.triabeauty.module.utilities;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public class PaymentUtil {
	
	public static Map<String,String> getCardTypes()
	{
		Map<String,String> cardTypes = new LinkedHashMap<String,String>();
		cardTypes.put("AMEX","American Express");
		cardTypes.put("DISCOVER","Discover");
		cardTypes.put("MASTRO","Master Card");
		cardTypes.put("VISA","Visa");
		return cardTypes;
	}
	
	public static List<String> getExpiryDateMonth()
	{
		List<String> dateMonth = new ArrayList<String>();
		dateMonth.add("01");
		dateMonth.add("02");
		dateMonth.add("03");
		dateMonth.add("04");
		dateMonth.add("05");
		dateMonth.add("06");
		dateMonth.add("07");
		dateMonth.add("08");
		dateMonth.add("09");
		dateMonth.add("10");
		dateMonth.add("11");
		dateMonth.add("12");
		return dateMonth;
	}
	
	public static List<String> getExpiryDateYear()
	{
		List<String> dateYear = new ArrayList<String>();
		dateYear.add("2013");
		dateYear.add("2014");
		dateYear.add("2015");
		dateYear.add("2016");
		dateYear.add("2017");
		dateYear.add("2018");
		dateYear.add("2019");
		dateYear.add("2020");
		dateYear.add("2021");
		dateYear.add("2022");
		dateYear.add("2023");
		return dateYear;
	}
}
