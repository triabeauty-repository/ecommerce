package com.triabeauty.module.utilities;

import info.magnolia.module.blossom.annotation.VirtualURIMapper;

@VirtualURIMapper
public class TriaVirtualUriMapping {

    public String campaignPage(String uri) {
        if (uri.equals("/campaign"))
            return "/articles/campaigns/campaign2013";
        return null;
    }
}
