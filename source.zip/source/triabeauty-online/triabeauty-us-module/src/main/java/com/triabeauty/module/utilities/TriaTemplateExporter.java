package com.triabeauty.module.utilities;

import info.magnolia.module.blossom.template.BlossomTemplateDefinition;
import info.magnolia.module.blossom.template.TemplateExporter;

public class TriaTemplateExporter extends TemplateExporter {

    @Override
    protected void registerTemplateDialog(BlossomTemplateDefinition templateDefinition) {
        templateDefinition.setTitle(templateDefinition.getTitle().toUpperCase());
        super.registerTemplateDialog(templateDefinition);
    }
}
