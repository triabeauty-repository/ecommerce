package com.triabeauty.module.components;

import info.magnolia.module.blossom.annotation.TabFactory;
import info.magnolia.module.blossom.annotation.Template;
import info.magnolia.module.blossom.dialog.TabBuilder;

import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;

import com.triabeauty.enterprise.entities.transactional.vo.Cart;
import com.triabeauty.enterprise.entities.transactional.vo.CartItem;
import com.triabeauty.enterprise.service.endpoint.remote.CartServiceRemote;
import com.triabeauty.enterprise.service.locator.Remote;

@Controller
@Template(title="MyBag Link", id="tria-us-cms-module:components/myBag")
public class MyBagLinkComponent {

	private static final Logger log = LoggerFactory
			.getLogger(MyBagLinkComponent.class);

    @RequestMapping(value = "/myBag")
    public String handleRequest(ModelMap model, HttpServletRequest request) {
    	log.warn("*******MyBag***********");
    	CartServiceRemote cartService = Remote.getCartSerice(request);
    	Cart cart=cartService.getSessionCart();
    	log.warn("cart: "+cart);
    	int basket=0;
    	if(cart!=null && !cart.getCartItems().isEmpty())
    	{
    		for(CartItem cartItem:cart.getCartItems())
    		{
    			basket+=cartItem.getQuantity();
    		}
    		model.addAttribute("basket", basket);
    	}else
    	{
    		model.addAttribute("basket", basket);
    	}
        return "components/myBagLink.ftl";
    }

    @TabFactory("Content")
    public void contentTab(TabBuilder tab) {
        tab.addLink("link", "Link", "");
        tab.addEdit("linkTitle", "Link Title", "");
    }
}
