package com.triabeauty.module.components;

import info.magnolia.module.blossom.annotation.TabFactory;
import info.magnolia.module.blossom.annotation.Template;
import info.magnolia.module.blossom.annotation.TemplateDescription;
import info.magnolia.module.blossom.dialog.TabBuilder;

import javax.jcr.Node;
import javax.jcr.RepositoryException;
import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.triabeauty.enterprise.service.endpoint.remote.CustomerServiceRemote;
import com.triabeauty.enterprise.service.locator.ServiceLocator;

@Controller
@Template(title = "Forgot Password Form", id = "tria-us-cms-module:components/forgotPassword", visible = true)
@TemplateDescription(value = "Forgot Password Form")
public class ForgotPasswordComponent {

	private static final Logger log = LoggerFactory
			.getLogger(ForgotPasswordComponent.class);

	@RequestMapping("/forgotPassword")
	public ModelAndView handleRequest(Node content, HttpServletRequest request,
			ModelMap model) throws RepositoryException {

		log.warn("*********forgotPassword start****************");
		String email = request.getParameter("email");
		log.warn("email: " + email);

		if (request.getMethod().equalsIgnoreCase("POST")) {
			try {
				CustomerServiceRemote customerService = (CustomerServiceRemote) ServiceLocator
						.lookUp(CustomerServiceRemote.class);
				customerService.forgotPassword(email);
				model.addAttribute("SUCCESS_MESSAGE", "Password has been reset successfully!");
			} catch (Exception e) {
				e.printStackTrace();
			}

		}
		log.warn("*********forgotPassword end****************");
		return new ModelAndView("components/forgotPasswordForm.ftl");
	}

	@TabFactory("forgotPassword Form")
	public void contentTab(TabBuilder tab) {
		tab.addStatic("This component requires no configuration");
		tab.addHidden("bogus", "value");

	}
}
