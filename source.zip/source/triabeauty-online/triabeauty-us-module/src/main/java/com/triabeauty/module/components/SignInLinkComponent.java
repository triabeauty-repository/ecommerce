package com.triabeauty.module.components;

import info.magnolia.module.blossom.annotation.TabFactory;
import info.magnolia.module.blossom.annotation.Template;
import info.magnolia.module.blossom.dialog.TabBuilder;

import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@Template(title="SignIn Link", id="tria-us-cms-module:components/signin")
public class SignInLinkComponent {

	private static final Logger log = LoggerFactory
			.getLogger(SignInLinkComponent.class);
	
    @RequestMapping(value = "/signin")
    public String handleRequest(ModelMap model, HttpSession session) {
    	log.warn("*******SingIn***********");
    	log.warn("user session:"+session.getAttribute("user"));
    	if(session.getAttribute("user")!=null)
    	{
    		model.addAttribute("user", session.getAttribute("user"));
    	}
        return "components/signInLink.ftl";
    }


    @TabFactory("Content")
    public void contentTab(TabBuilder tab) {
        tab.addLink("link", "Link", "");
        tab.addEdit("linkTitle", "Link Title", "");
    }
}
