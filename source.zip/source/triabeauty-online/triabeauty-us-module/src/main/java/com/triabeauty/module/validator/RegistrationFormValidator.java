package com.triabeauty.module.validator;

import org.springframework.validation.Errors;
import org.springframework.validation.ValidationUtils;
import org.springframework.validation.Validator;

import com.triabeauty.module.beans.RegistrationForm;

public class RegistrationFormValidator implements Validator {

    public boolean supports(Class clazz) {
        return clazz.equals(RegistrationForm.class);
    }

    
    public void validate(Object target, Errors errors) {
        ValidationUtils.rejectIfEmptyOrWhitespace(errors, "firstName", "required", "first Name is required");
        ValidationUtils.rejectIfEmptyOrWhitespace(errors, "lastName", "required", "last Name is required");
        ValidationUtils.rejectIfEmptyOrWhitespace(errors, "password", "required", "password is required");
        ValidationUtils.rejectIfEmptyOrWhitespace(errors, "verifyPassword", "required", "verify password is required");
        ValidationUtils.rejectIfEmptyOrWhitespace(errors, "email", "required", "E-mail is required");
    }
}
