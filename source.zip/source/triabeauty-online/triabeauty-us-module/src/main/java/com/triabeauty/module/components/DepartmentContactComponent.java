package com.triabeauty.module.components;

import info.magnolia.module.blossom.annotation.TabFactory;
import info.magnolia.module.blossom.annotation.Template;
import info.magnolia.module.blossom.annotation.TemplateDescription;
import info.magnolia.module.blossom.dialog.TabBuilder;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import javax.jcr.Node;
import javax.jcr.RepositoryException;
import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.triabeauty.enterprise.entities.transactional.vo.Department;
import com.triabeauty.enterprise.entities.transactional.vo.EmailSubscription;
import com.triabeauty.enterprise.service.constants.Country;
import com.triabeauty.enterprise.service.endpoint.remote.CustomerServiceRemote;
import com.triabeauty.enterprise.service.endpoint.remote.MailServiceRemote;
import com.triabeauty.enterprise.service.locator.ServiceLocator;
import com.triabeauty.module.beans.DepartmentContactUsData;
import com.triabeauty.module.utilities.ReCaptchaUtil;

@Controller
@Template(title = "DepartmentContactComponent", id = "tria-us-cms-module:components/contactUs", visible = true)
@TemplateDescription(value = "ContactUs Form ")
public class DepartmentContactComponent {

	private static final Logger log = LoggerFactory
			.getLogger(DepartmentContactComponent.class);
	MailServiceRemote mailService = (MailServiceRemote) ServiceLocator
			.lookUp(MailServiceRemote.class);
	CustomerServiceRemote customerService = (CustomerServiceRemote) ServiceLocator
			.lookUp(CustomerServiceRemote.class);
	@RequestMapping(value = "/contactUs", method = RequestMethod.GET)
	public String render(@ModelAttribute("contactUsForm") DepartmentContactUsData contactUsForm,
			BindingResult result, Node content, HttpServletRequest request,
			ModelMap model) {
		log.warn("***********Contact Us Render**************");

		String reCaptcha=ReCaptchaUtil.createReCaptcha();
		log.warn("recapthc"+reCaptcha);
		model.addAttribute("ReCaptcha", reCaptcha);
		model.addAttribute("departments",departments());
		model.addAttribute("subjects", subjects());

		
		return "components/customercare.ftl";
	}
	@RequestMapping(value = "/contactUs", method = RequestMethod.POST)
	public ModelAndView submit(
			@ModelAttribute("contactUsForm") DepartmentContactUsData contactUsForm,
			BindingResult result, Node content, HttpServletRequest request,
			ModelMap model) throws RepositoryException{
		log.warn("***********ContactUs Submit**************");
		final String challenge = request.getParameter("recaptcha_challenge_field");
		final String responseField = request.getParameter("recaptcha_response_field");
		final String remoteAddr = request.getRemoteAddr();
		String newsletter=request.getParameter("newsletter");
		ModelAndView modelview=new ModelAndView();
		final Map<String, String> subjectMap = new HashMap<String, String>();
		subjectMap.put("Order/Shipping Questions", "ccorders@triabeauty.com");
		subjectMap.put("Product Information", "ccgeneral@triabeauty.com");
		subjectMap.put("Return/Exchange Questions", "ccreturns@triabeauty.com");
		subjectMap.put("EZ Pay Payment Plan Questions", "ccgeneral@triabeauty.com");
		subjectMap.put("Questions Re:  Activation or Need Help Activating", "ccactivation@triabeauty.com");
		subjectMap.put("Warranty/Money Back Guarantee", "ccgeneral@triabeauty.com");
		subjectMap.put("Promo Questions", "ccgeneral@triabeauty.com");
		subjectMap.put("Replenishment", "ccgeneral@triabeauty.com");
		subjectMap.put("General Questions/Other", "ccgeneral@triabeauty.com");
		String mailSubject = "Hello Customer Care Executive";		
		//Customer Care DATA printing in Log file\
		log.info("****Customer Care DATA****");
		log.info("Email:-" + contactUsForm.getEmail());
		log.info("Name:-" + contactUsForm.getCustomerName());
		log.info("Department:-" + contactUsForm.getDepartment());
		log.info("****End of Customer Care DATA****");
		final boolean reCaptchaValid = ReCaptchaUtil.validateReCaptcha(remoteAddr, challenge, responseField);
		boolean isTrue = false;
		String mailId;
		if (reCaptchaValid)
		{
			if (contactUsForm.getDepartment().equalsIgnoreCase("Customer Care") && !contactUsForm.getSubject().isEmpty())
			{
				contactUsForm.setCcEmail(subjectMap.get(contactUsForm.getSubject()));
				mailSubject = contactUsForm.getSubject();
			}
			contactUsForm.setSubject(mailSubject);
			Department selectedDepartment = null;			
			try {
				selectedDepartment = customerService.getDepartment(contactUsForm.getDepartment());
				mailId=selectedDepartment.getEmail();
				if (contactUsForm.getCcEmail() != null && !contactUsForm.getCcEmail().isEmpty())
				{
					mailId = contactUsForm.getCcEmail();
				}
				mailService.contactUs(contactUsForm.getCustomerName(),mailId, contactUsForm.getOrder(), contactUsForm.getTelephone(),
						selectedDepartment.getDepartmentName(), contactUsForm.getComments(), Country.valueOf("US"), contactUsForm.getEmail(), mailSubject);				
				if(contactUsForm.getNewsletter().equalsIgnoreCase("yes")){
					String source="tb_contactus";				
					EmailSubscription subscriptionData = new EmailSubscription();
					subscriptionData.setEmail(contactUsForm.getEmail());
					subscriptionData.setFirstName(contactUsForm.getCustomerName());
					subscriptionData.setSourceValue(source);
					customerService.activateEmailSubscription(subscriptionData);
				}
				model.addObject("SUCCESS_MESSAGE", "Submitted Successfully.");
			} catch (Exception e) {
				log.warn("error in customercare"+e.getMessage());
				model.addObject("ERROR_MESSAGE", "Error while doing contact.");
			}
					
		}
		else
		{
			model.addObject("ERROR_MESSAGE", "Your Captcha submission was incorrect. Please try again.");
		}
		String reCaptcha=ReCaptchaUtil.createReCaptcha();
		log.warn("recapthc"+reCaptcha);
		model.addAttribute("ReCaptcha", reCaptcha);
		model.addAttribute("departments",departments());
		model.addAttribute("subjects", subjects());

		modelview.setViewName("components/customercare.ftl");

		if (log.isDebugEnabled())
		{
			log.debug("DepartmentContactController onSubmit method - exit");
		}
		return modelview;
		
	}
	

	@TabFactory("ContactUs Form")
	public void contentTab(TabBuilder tab) {
		tab.addUuidLink("successPage", "Success page", "");
		tab.addUuidLink("logInPage", "LogIn page", "");
	}
	
	private Map departments() {
		List<Department> departments = new ArrayList<Department>();
		try {			
			departments = customerService.getDepartments();
		} catch (Exception e) {
			log.warn("error while getting departments");
		}

		Map department = new LinkedHashMap();
		for (Department departmentvar : departments) {
			department.put(departmentvar.getDepartmentCode(), departmentvar.getDepartmentName());
		}

		
		return department;
	}
	
	private Map subjects() {
		Map<String, String> subject = new LinkedHashMap<String, String>();
		subject.put("Order/Shipping Questions", "Order/Shipping Questions");
		subject.put("Return/Exchange Questions", "Return/Exchange Questions");
		subject.put("Questions Re:  Activation or Need Help Activating", "Questions Re:  Activation or Need Help Activating");
		subject.put("General Questions/Other", "General Questions/Other");
		return subject;
	}

	


}
