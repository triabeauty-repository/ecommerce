package com.triabeauty.module.beans;


public class QuestionnaireForm
{

	private String[] bodyLocations;
	private String[] hairColor;
	private String primarySkinTone;
	private String secondarySkinTone;
	private String selectedHairColor;


	/**
	 * @return the selectedHairColor
	 */
	public String getSelectedHairColor()
	{
		return selectedHairColor;
	}

	/**
	 * @param selectedHairColor
	 *           the selectedHairColor to set
	 */
	public void setSelectedHairColor(final String selectedHairColor)
	{
		this.selectedHairColor = selectedHairColor;
	}

	/**
	 * @return the primarySkinTone
	 */
	public String getPrimarySkinTone()
	{
		return primarySkinTone;
	}

	/**
	 * @param primarySkinTone
	 *           the primarySkinTone to set
	 */
	public void setPrimarySkinTone(final String primarySkinTone)
	{
		this.primarySkinTone = primarySkinTone;
	}

	/**
	 * @return the secondarySkinTone
	 */
	public String getSecondarySkinTone()
	{
		return secondarySkinTone;
	}

	/**
	 * @param secondarySkinTone
	 *           the secondarySkinTone to set
	 */
	public void setSecondarySkinTone(final String secondarySkinTone)
	{
		this.secondarySkinTone = secondarySkinTone;
	}

	/**
	 * @return the bodyLocations
	 */
	public String[] getBodyLocations()
	{
		return bodyLocations;
	}

	/**
	 * @param bodyLocations
	 *           the bodyLocations to set
	 */
	public void setBodyLocations(final String[] bodyLocations)
	{
		this.bodyLocations = bodyLocations;
	}

	/**
	 * @return the hairColor
	 */
	public String[] getHairColor()
	{
		return hairColor;
	}

	/**
	 * @param hairColor
	 *           the hairColor to set
	 */
	public void setHairColor(final String[] hairColor)
	{
		this.hairColor = hairColor;
	}

}
