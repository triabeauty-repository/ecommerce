package com.triabeauty.module.controllers;

import java.io.PrintWriter;
import java.text.DecimalFormat;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.triabeauty.enterprise.entities.transactional.vo.Address;
import com.triabeauty.enterprise.entities.transactional.vo.Cart;
import com.triabeauty.enterprise.service.constants.Country;
import com.triabeauty.enterprise.service.endpoint.remote.CartServiceRemote;
import com.triabeauty.enterprise.service.locator.Remote;

@Controller
public class TaxController {
	private static final Logger log = LoggerFactory.getLogger(TaxController.class);

	@RequestMapping("/tax")
	@ResponseBody

	public ModelAndView getTax(HttpServletRequest request,HttpServletResponse response) {
		final JSONObject taxValues = new JSONObject();
		final DecimalFormat df = new DecimalFormat("#.00");
		log.info("************Tax Controller Start**************");
		CartServiceRemote cartService = Remote.getCartSerice(request);
		PrintWriter out;
		String country="US";
		if(request.getParameter("country").toString().equalsIgnoreCase("CAN"))
		{
			country="CA";
		}

		try {
			out = response.getWriter();

			Address shippingAddress=new Address();
			if(request.getParameter("firstName")!=null)
			{
				shippingAddress.setFirstName(request.getParameter("firstName").toString());
			}
			if(request.getParameter("lastname")!=null)
			{
				shippingAddress.setLastName(request.getParameter("lastname").toString());
			}
			if(request.getParameter("shippingAddress1")!=null)
			{
				shippingAddress.setAddressLine1(request.getParameter("shippingAddress1").toString());
			}
			if(request.getParameter("shippingAddress2")!=null)
			{
				shippingAddress.setAddressLine2(request.getParameter("shippingAddress2").toString());
			}
			if(request.getParameter("city")!=null)
			{
				shippingAddress.setCity(request.getParameter("city").toString());
			}
			shippingAddress.setCountry(Country.valueOf(country));
			if(request.getParameter("state")!=null)
			{
				shippingAddress.setStateCode(request.getParameter("state").toString());
			}
			if(request.getParameter("zipCode")!=null)
			{
				shippingAddress.setZip(request.getParameter("zipCode").toString());
			}
			cartService.setShippingAddress(shippingAddress);
			Cart cart=cartService.getSessionCart();
			taxValues.put("totalTax", df.format(cart.getTaxAmount()));
			taxValues.put("totalPrice", df.format(cart.getTotalPrice()));
			taxValues.put("deliveryCost", df.format(cart.getShippingCost()));
			out.print(taxValues);
			log.info("taxValues: "+taxValues);
		} catch (Exception e) {
			e.printStackTrace();
		}
		log.info("************Tax Controller End**************");

		return null ;
	}


}
