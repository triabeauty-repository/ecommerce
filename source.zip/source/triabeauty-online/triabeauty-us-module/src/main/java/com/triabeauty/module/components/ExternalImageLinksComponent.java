package com.triabeauty.module.components;

import info.magnolia.module.blossom.annotation.TabFactory;
import info.magnolia.module.blossom.annotation.Template;
import info.magnolia.module.blossom.dialog.TabBuilder;

import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@Template(title = "External Links & Images", id = "tria-us-cms-module:components/ExternalImageLinks")
public class ExternalImageLinksComponent{

	// @Inject
	// private SimpleService simpleService;

/*	public ExternalImageLinksComponent(Node content,
			TemplateDefinition definition, RenderingModel<?> parent,
			STKTemplatingFunctions stkFunctions,
			TemplatingFunctions templatingFunctions) {
		super(content, definition, parent, stkFunctions, templatingFunctions);
		// TODO Auto-generated constructor stub
	}
*/
	@RequestMapping("/externalImageLinks")
	public String render(ModelMap model) throws Exception {

		System.out.println("  ExternalImgLink component render method");

		return "components/externalImageLinks.ftl";
	}

	@TabFactory("Content")
	public void contentTab(TabBuilder tab) {
		tab.addFile("image", "Image", "Logo").setRequired(true);
		//tab.addEdit("link", "Link", "External Link").setRequired(true);
		//tab.addEdit("link", "LinkTitle", "Link Title").setRequired(true);
		tab.addCheckbox("inheritable", "Inherited", "");
	}
}
