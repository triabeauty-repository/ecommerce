package com.triabeauty.module.components;

import info.magnolia.module.blossom.annotation.TabFactory;
import info.magnolia.module.blossom.annotation.Template;
import info.magnolia.module.blossom.annotation.TemplateDescription;
import info.magnolia.module.blossom.dialog.TabBuilder;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.triabeauty.enterprise.entities.product.vo.Store;
import com.triabeauty.enterprise.service.constants.Country;
import com.triabeauty.enterprise.service.constants.StateCode;
import com.triabeauty.enterprise.service.endpoint.remote.ProductCatalogServiceRemote;
import com.triabeauty.enterprise.service.locator.ServiceLocator;

@Controller
@Template(title = "StoreListComponent", id = "tria-us-cms-module:components/storeList", visible = true)
@TemplateDescription(value = "StoreList Form")
public class StoreListComponent {

	private static final Logger log = LoggerFactory
			.getLogger(StoreListComponent.class);

	ProductCatalogServiceRemote storeLocatorService = (ProductCatalogServiceRemote) ServiceLocator
			.lookUp(ProductCatalogServiceRemote.class);
	@RequestMapping(value = "/storeList")
	public ModelAndView submit( HttpServletRequest request,HttpServletResponse response,
			ModelMap model) throws Exception{
		log.warn("***********StoreLocator**************");

		ModelAndView modelview=new ModelAndView();

		List<String> addresses = new ArrayList();
		final List<String> stateList = new ArrayList();
		final Map<String, List<String>> map = new HashMap<String, List<String>>();
		Country country=Country.valueOf("US");
		String stateName = null;
		final List<Store> storeList = storeLocatorService.getAllStoreLists(country);
		if (storeList != null && storeList.size() > 0)
		{
			for (int i = 0; i < storeList.size(); i++)
			{
				String address = "";
				if (!storeList.get(i).getLocation().getAddress().getStateCode().toString().equalsIgnoreCase(stateName))
				{
					addresses = new ArrayList();
					//address = "<b>"+storeList.getResult().get(i).getRegion().getName()+"</b><br />";
					stateName = StateCode.valueOf(storeList.get(i).getLocation().getAddress().getStateCode()).getName();
					stateList.add(stateName);
				}
				else
				{
					address = "<br>";
				}

				address = address + storeList.get(i).getStoreTitle();
				address = address + "<br>" + storeList.get(i).getLocation().getAddress().getAddressLine1();
				if (storeList.get(i).getLocation().getAddress().getAddressLine2() != null)
				{
					address = address + "<br>" + storeList.get(i).getLocation().getAddress().getAddressLine2();
				}
				if (storeList.get(i).getLocation().getAddress().getCity() != null)
				{
					address = address + "<br>" +storeList.get(i).getLocation().getAddress().getCity() + ", ";
				}
				else
				{
					address = address + "<br>";
				}

				address = address + storeList.get(i).getLocation().getAddress().getStateCode().toString() + " "
						+ storeList.get(i).getLocation().getAddress().getZip();
				if (storeList.get(i).getPhoneNumber() != null)
				{
					address = address + "<br>" + storeList.get(i).getPhoneNumber();
				}

				if (storeList.get(i).getURL() != null)
				{
					address = address + "<br><a href='http://" + storeList.get(i).getURL()
							+ "' target='_new' rel='nofollow'>" + storeList.get(i).getURL() + "</a>";
				}

				address = address + "<br>";

				if (storeList.get(i).isLHRAvailable())
				{
					address = address + "<img src=\'"+request.getContextPath()+"/docroot/img/bgs/us/global/LHRS_green.gif\' alt=\'Laser Hair Removal\'>";
				}

				if ((storeList.get(i).isBLAAvailable()))
				{
					address = address+ "<span style=\"padding-left:8px;\"><img src=\'"+request.getContextPath()+"/docroot/img/bgs/us/global/SCS_blue.gif\' alt=\'Skin Clarifying System\'></span>";
				}
				address = address + "<br>";
				addresses.add(address);
				map.put(stateName, addresses);
			}
		}
		model.addObject("addresses", addresses);
		model.addObject("stateList", stateList);
		model.addObject("storeMap", map);
		
		
		modelview.setViewName("components/storeList.ftl");

		return modelview;
		
	}
	

	@TabFactory("StoreList Form")
	public void contentTab(TabBuilder tab) {
		tab.addUuidLink("successPage", "Success page", "");
		tab.addUuidLink("logInPage", "LogIn page", "");
	}
	

	


}
