package com.triabeauty.module.validator;

import org.springframework.validation.Errors;
import org.springframework.validation.ValidationUtils;
import org.springframework.validation.Validator;

import com.triabeauty.module.beans.AddressBookForm;

public class AddressBookFormValidator implements Validator {

   
	

	
	
    public boolean supports(Class clazz) {
        return clazz.equals(AddressBookForm.class);
    }

    
    public void validate(Object target, Errors errors) {
        ValidationUtils.rejectIfEmptyOrWhitespace(errors, "shippingFirstName", "required", "first Name is required");
        ValidationUtils.rejectIfEmptyOrWhitespace(errors, "shippingLastName", "required", "last Name is required");
        ValidationUtils.rejectIfEmptyOrWhitespace(errors, "shippingAddress1", "required", "Address1 is required");
        ValidationUtils.rejectIfEmptyOrWhitespace(errors, "shippingCity", "required", "city is required");
        ValidationUtils.rejectIfEmptyOrWhitespace(errors, "shippingState", "required", "state is required");
        ValidationUtils.rejectIfEmptyOrWhitespace(errors, "shippingZip", "required", "zipcode is required");
        
        ValidationUtils.rejectIfEmptyOrWhitespace(errors, "billingFirstName", "required", "first Name is required");
        ValidationUtils.rejectIfEmptyOrWhitespace(errors, "billingLastName", "required", "last Name is required");
        ValidationUtils.rejectIfEmptyOrWhitespace(errors, "billingAddress1", "required", "Address1 is required");
        ValidationUtils.rejectIfEmptyOrWhitespace(errors, "billingCity", "required", "city is required");
        ValidationUtils.rejectIfEmptyOrWhitespace(errors, "billingState", "required", "state is required");
        ValidationUtils.rejectIfEmptyOrWhitespace(errors, "billingZip", "required", "zipcode is required");
    }
}
