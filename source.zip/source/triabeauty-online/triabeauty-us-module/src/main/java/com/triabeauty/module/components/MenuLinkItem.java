
package com.triabeauty.module.components;

import info.magnolia.module.blossom.annotation.TabFactory;
import info.magnolia.module.blossom.annotation.Template;
import info.magnolia.module.blossom.annotation.TemplateDescription;
import info.magnolia.module.blossom.dialog.TabBuilder;

import javax.jcr.Node;
import javax.jcr.RepositoryException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@Template(
    id="exmp-blossom:components/menuLinkItem",
    title="Menu Link Item"
)
@TemplateDescription("the component of a menu item of a link.")
public class MenuLinkItem {
    
    private static final Logger LOG = LoggerFactory.getLogger(
        MenuLinkItem.class
    );
    
    ///////////////////////////////////////////////////////////////////////////
    // public methods
    
    @RequestMapping("/menuLinkItem") 
    public String render(
        ModelMap model,
        Node content
    ) throws RepositoryException {
        LOG.trace("called.");
        return "components/menuLinkItem.ftl";
    }
    
    @TabFactory("Menu Link Item")
    public void addDialog(TabBuilder tab) {
        tab.addEdit(
            "linkText",
            "Link Text",
            "the link text of a menu item."
        );
        tab.addLink(
            "link",
            "Link URL",
            "the link url of a menu item."
        );
    }
    
}
