package com.triabeauty.module.beans;



public class ActivationForm
{

	private String serialNumber;
	private String email;
	private String firstName;
	private String lastName;
	private String purchasedPlace;
	private String howDidYouHear;
	private boolean customerCare = false;
	private String password;
	private String repeatPassword;
	private boolean customerExists = false;
	private boolean interested = true;
	public String getSerialNumber() {
		return serialNumber;
	}
	public void setSerialNumber(String serialNumber) {
		this.serialNumber = serialNumber;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String getPurchasedPlace() {
		return purchasedPlace;
	}
	public void setPurchasedPlace(String purchasedPlace) {
		this.purchasedPlace = purchasedPlace;
	}
	public String getHowDidYouHear() {
		return howDidYouHear;
	}
	public void setHowDidYouHear(String howDidYouHear) {
		this.howDidYouHear = howDidYouHear;
	}
	public boolean isCustomerCare() {
		return customerCare;
	}
	public void setCustomerCare(boolean customerCare) {
		this.customerCare = customerCare;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getRepeatPassword() {
		return repeatPassword;
	}
	public void setRepeatPassword(String repeatPassword) {
		this.repeatPassword = repeatPassword;
	}
	public boolean isCustomerExists() {
		return customerExists;
	}
	public void setCustomerExists(boolean customerExists) {
		this.customerExists = customerExists;
	}
	public boolean isInterested() {
		return interested;
	}
	public void setInterested(boolean interested) {
		this.interested = interested;
	}

	


}
