package com.triabeauty.module.validator;

import org.springframework.validation.Errors;
import org.springframework.validation.ValidationUtils;
import org.springframework.validation.Validator;

import com.triabeauty.module.beans.LogInForm;

public class LogInFormValidator implements Validator {

	public boolean supports(Class clazz) {
		return clazz.equals(LogInForm.class);
	}

	public void validate(Object target, Errors errors) {
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "userPassword",
				"required", "password is required");
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "emailId",
				"required", "E-mail is required");
	}
}
