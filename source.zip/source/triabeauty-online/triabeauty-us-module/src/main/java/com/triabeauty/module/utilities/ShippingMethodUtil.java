package com.triabeauty.module.utilities;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.triabeauty.enterprise.entities.transactional.vo.ShippingCompanyService;
import com.triabeauty.enterprise.service.constants.Country;
import com.triabeauty.enterprise.service.endpoint.remote.CartServiceRemote;
import com.triabeauty.enterprise.service.locator.Remote;

public class ShippingMethodUtil {
	
	private static final Logger log = LoggerFactory
			.getLogger(ShippingMethodUtil.class);
	
	public static Map<String,String> getShippingMethods(HttpServletRequest request,Country country)
	{
		final String CHANNEL = "WEB";
		CartServiceRemote cartService = Remote.getCartSerice(request);
		List<ShippingCompanyService> shippingServices=cartService.getShippingServices(country.US,CHANNEL);
		log.warn("shippingServices: "+shippingServices);
		Map<String,String> shippingMethods = new LinkedHashMap<String,String>();
		for(ShippingCompanyService shippingService:shippingServices)
		{
			shippingMethods.put(shippingService.getShippingServiceCode(),shippingService.getServiceTitle()+"-$"+shippingService.getServiceCostList().get(0).getPrice().intValue());
		}
		
		return shippingMethods;
	}
}
