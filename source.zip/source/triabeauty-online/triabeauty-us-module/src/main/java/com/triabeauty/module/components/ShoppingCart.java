/** 
 * Copyright (c) 2009 TRIA Beauty INC. All Rights Reserved.
 *
 * This software is the confidential and proprietary information of TRIA
 * Beauty INC ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the terms
 * of the license agreement you entered into with TRIA Beauty INC.
 *
 * TRIA Beauty INC MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY OF 
 * SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
 * PURPOSE, OR NON-INFRINGEMENT. TRIA Beauty INC SHALL NOT BE LIABLE FOR ANY
 * DAMAGES SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 **/

/**
 *FileName:ShoppingCart.java
 *
 *
 *@author 
 *Created By: 
 *Reviewed By : Sivaramakrishna
 *
 *@Creation Date: ${date}
 *@Last Modified Date: <last modified date>
 *
 *@version History
 *@<history goes here>
 *Update By <User Name> on <Date of modification> for <Reason for modification>  *
 **/

package com.triabeauty.module.components;


import info.magnolia.module.blossom.annotation.TabFactory;
import info.magnolia.module.blossom.annotation.Template;
import info.magnolia.module.blossom.dialog.TabBuilder;
import info.magnolia.module.blossom.view.UuidRedirectView;

import java.util.ArrayList;
import java.util.List;

import javax.jcr.Node;
import javax.jcr.RepositoryException;
import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.triabeauty.enterprise.entities.product.vo.Product;
import com.triabeauty.enterprise.entities.transactional.vo.Address;
import com.triabeauty.enterprise.entities.transactional.vo.Cart;
import com.triabeauty.enterprise.entities.transactional.vo.CartItem;
import com.triabeauty.enterprise.entities.transactional.vo.User;
import com.triabeauty.enterprise.service.constants.AddressType;
import com.triabeauty.enterprise.service.constants.Country;
import com.triabeauty.enterprise.service.constants.Region;
import com.triabeauty.enterprise.service.endpoint.remote.CartServiceRemote;
import com.triabeauty.enterprise.service.locator.Remote;
import com.triabeauty.module.beans.PaymentServiceForm;

/**
 * Renders the contents of the shopping cart in a small summarized format.
 */
@Controller
@Template(title = "ShoppingCart", id = "tria-us-cms-module:components/shoppingCart")
public class ShoppingCart {

	private static final Logger log = LoggerFactory
			.getLogger(ShoppingCart.class);

	@RequestMapping(value = "/shoppingCart", method = RequestMethod.GET)
	public String render(@ModelAttribute PaymentServiceForm paymentServiceForm, ModelMap model, HttpServletRequest request) {
		log.warn("*****Shopping Cart Render*******");
		CartServiceRemote cartService = Remote.getCartSerice(request);
		Cart cart=cartService.getSessionCart();
		User user=(User)request.getAttribute("user");

		if(user!=null)
		{
			if(cart.getShippingAddress()==null && user.getShippingAddress()!=null)
			{
				cartService.setShippingAddress(user.getShippingAddress());
			}
			if(cart.getBillingAddress()==null && user.getBillingAddress()!=null)
			{
				cartService.setBillingAddress(user.getBillingAddress());
			}
			if(cart.getEmail()==null && user.getEmail()!=null)
			{
				cartService.setEmail(user.getEmail());
			}
		}
		cart=cartService.getSessionCart();
		model.put("cart", cart);
		if(cart!=null){
			paymentServiceForm=preparePaymentServiceForm(cart, paymentServiceForm);
		}
		if(paymentServiceForm!=null)
		{
			log.warn(paymentServiceForm.toString());
			model.addAttribute("paymentServiceForm", paymentServiceForm);
			if(paymentServiceForm.getShippingCountry()!=null && paymentServiceForm.getShippingCountry().equalsIgnoreCase("CAN"))
			{
				model.addAttribute("nonCanadaProducts", request.getSession().getAttribute("nonCanadaProducts"));
			}
		}
		log.warn("*****Shopping Cart Render End*******");
		return "components/shoppingCart.ftl";
	}

	@TabFactory("Content")
	public void contentTab(TabBuilder tab) {
		tab.addUuidLink("successPage", "Success page", "");
	}

	@RequestMapping(value = "/shoppingCart", method = RequestMethod.POST)
	public ModelAndView submit(@ModelAttribute PaymentServiceForm paymentServiceForm, BindingResult result, 
			Node content, ModelMap model, HttpServletRequest request) throws RepositoryException{
		log.warn("*****Shopping Cart*******");
		log.warn("action: "+request.getParameter("action"));
		log.warn("PaymentServiceForm: "+paymentServiceForm.toString());
		if ("update".equals(request.getParameter("action"))) {
			update(request);
			return new ModelAndView("redirect:" + request.getRequestURL());
		}else if ("remove".equals(request.getParameter("action"))) {
			remove(request);
			return new ModelAndView("redirect:" + request.getRequestURL());
		}else if ("applyPromotion".equals(request.getParameter("action"))) {
			applyPromotion(request);
			return new ModelAndView("redirect:" + request.getRequestURL());
		}else {
			checkout(paymentServiceForm,request);
			CartServiceRemote cartService = Remote.getCartSerice(request);
			Cart cart=cartService.getSessionCart();
			if(cart.getShippingCompanyService()!=null)
			{
				paymentServiceForm.setShippingMethod(cart.getShippingCompanyService().getServiceTitle());
			}
			if(paymentServiceForm.getCountryCode().equalsIgnoreCase("CAN"))
			{
				List<Product> nonCanadaProducts=nonCanadaProducts(cart);
				log.warn("nonCanadaProducts: "+nonCanadaProducts);
				request.getSession().setAttribute("nonCanadaProducts", nonCanadaProducts);
				if (!nonCanadaProducts.isEmpty())
				{
					model.addAttribute("nonCanadaProducts", nonCanadaProducts);
					return new ModelAndView("redirect:" + request.getRequestURL());
				}
			}
			request.setAttribute("paymentServiceForm", paymentServiceForm);
			return new ModelAndView(new UuidRedirectView("website", content
					.getProperty("successPage").getString()));
		}

	}


	private List<Product> nonCanadaProducts(Cart cart) 
	{

		log.warn("*****nonCanadaProducts start*******");
		List<Product> nonCanadaProducts=new ArrayList<Product>();
		for (final CartItem cartItem : cart.getCartItems())
		{
			if (cartItem.getProduct().isAvailableForCanada() != null)
			{
				if (!cartItem.getProduct().isAvailableForCanada())
				{
					nonCanadaProducts.add(cartItem.getProduct());
					log.warn("Prodcuts That not belongs to Canada" + cartItem.getProduct().getSku().getCode());
				}
			}
			else
			{
				log.warn("The value for IsAvailableForCanada is giving null for the product : "
						+ cartItem.getProduct().getSku().getCode());
				nonCanadaProducts.add(cartItem.getProduct());
			}
		}
		log.warn("*****nonCanadaProducts end*******");
		return nonCanadaProducts;
	}
	

	private void update(HttpServletRequest request) 
	{

		log.warn("*****Shopping Cart Update*******");
		log.warn("catalogSkuId: "+request.getParameter("catalogSkuId"));


		String productCode=request.getParameter("catalogSkuId");
		Integer updatedQuantity=Integer.parseInt(request.getParameter("quantity"));
		log.warn("cartItemId: "+productCode);
		log.warn("quantity: "+updatedQuantity);
		try {
			CartServiceRemote cartService = Remote.getCartSerice(request);
			cartService.updateCart(productCode, updatedQuantity);
			request.getSession().setAttribute("cart", cartService.getSessionCart());
		} catch (Exception e) {
			e.printStackTrace();
			log.error("Exception occured while updating the cart: "
					+ e.getMessage());
		}
	}
	private void remove(HttpServletRequest request) 
	{
		log.warn("*****Shopping Cart Remove*******");
		log.warn("cartItemId: "+request.getParameter("catalogSkuId"));
		String productCode=request.getParameter("catalogSkuId");

		try {
			CartServiceRemote cartService = Remote.getCartSerice(request);
			cartService.deleteCartItem(productCode);
			request.getSession().setAttribute("cart", cartService.getSessionCart());
		} catch (Exception e) {
			e.printStackTrace();
			log.error("Exception occured while removing the product from cart: "
					+ e.getMessage());
		}
	}
	private void applyPromotion(HttpServletRequest request) 
	{
		log.warn("*****Shopping Cart applyPromotion Start*******");

		String promotionCode=request.getParameter("promoCode");
		try {
			CartServiceRemote cartService = Remote.getCartSerice(request);
			log.warn("applying promocode: "+promotionCode);
			cartService.applyPromotion(promotionCode, Country.US);
			request.getSession().setAttribute("cart", cartService.getSessionCart());
		} catch (Exception e) {
			e.printStackTrace();
			log.error("Exception occured while applying the promotion code: "
					+ e.getMessage());
		}
		log.warn("*****Shopping Cart applyPromotion End*******");
	}
	private void checkout(PaymentServiceForm paymentServiceForm,HttpServletRequest request) 
	{
		log.warn("*****Shopping Cart Checkout*******");
		String country="US";
		try {
			CartServiceRemote cartService = Remote.getCartSerice(request);

			log.warn("Country code: "+paymentServiceForm.getCountryCode());
			
			if(paymentServiceForm.getCountryCode().equalsIgnoreCase("CAN"))
			{
				country="CA";
			}
			cartService.setEmail(paymentServiceForm.getEmail());
			Address shippingAddress=new Address();
			shippingAddress.setAddressType(AddressType.SHIPPING);
			shippingAddress.setFirstName(paymentServiceForm.getShippingFirstName());
			shippingAddress.setLastName(paymentServiceForm.getShippingLastName());
			shippingAddress.setAddressLine1(paymentServiceForm.getShippingAddress1());
			shippingAddress.setAddressLine2(paymentServiceForm.getShippingAddress2());
			shippingAddress.setCity(paymentServiceForm.getShippingCity());
			shippingAddress.setCountry(Country.valueOf(country));
			shippingAddress.setStateCode(paymentServiceForm.getShippingState());
			shippingAddress.setRegion(Region.NORTH_AMERICAN);
			shippingAddress.setZip(paymentServiceForm.getShippingZip());
			shippingAddress.setPhoneNumber1(paymentServiceForm.getShippingPhone1() + "-"
					+paymentServiceForm.getShippingPhone2() + "-" + paymentServiceForm.getShippingPhone3());

			cartService.setShippingAddress(shippingAddress);

			Address billingAddress=new Address();
			billingAddress.setAddressType(AddressType.BILLING);
			billingAddress.setFirstName(paymentServiceForm.getBillingFirstName());
			billingAddress.setLastName(paymentServiceForm.getBillingLastName());
			billingAddress.setAddressLine1(paymentServiceForm.getBillingAddress1());
			billingAddress.setAddressLine2(paymentServiceForm.getBillingAddress2());
			billingAddress.setCity(paymentServiceForm.getBillingCity());
			billingAddress.setCountry(Country.valueOf(country));
			billingAddress.setStateCode(paymentServiceForm.getBillingState());
			billingAddress.setRegion(Region.NORTH_AMERICAN);
			billingAddress.setZip(paymentServiceForm.getBillingZip());
			billingAddress.setPhoneNumber1(paymentServiceForm.getBillingPhone1() + "-"
					+ paymentServiceForm.getBillingPhone2() + "-" + paymentServiceForm.getBillingPhone3());

			cartService.setBillingAddress(billingAddress);

			log.warn("*****Shopping Cart Checkout End*******");
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	PaymentServiceForm preparePaymentServiceForm(Cart cart,PaymentServiceForm paymentServiceForm)
	{
		Address shippingAddress=cart.getShippingAddress();
		Address billingAddress=cart.getShippingAddress();
		log.warn("shippingAddress: "+shippingAddress);
		log.warn("billingAddress: "+shippingAddress);
		paymentServiceForm.setEmail(cart.getEmail());
		String country="USA";
	
		if(shippingAddress!=null)
		{
			if(shippingAddress.getCountry().getCode().equalsIgnoreCase("CA"))
			{
				country="CAN";
			}
			paymentServiceForm.setShippingFirstName(shippingAddress.getFirstName());
			paymentServiceForm.setShippingLastName(shippingAddress.getLastName());
			paymentServiceForm.setShippingAddress1(shippingAddress.getAddressLine1());
			paymentServiceForm.setShippingAddress2(shippingAddress.getAddressLine2());
			paymentServiceForm.setShippingCity(shippingAddress.getCity());
			paymentServiceForm.setShippingState(shippingAddress.getStateCode());
			paymentServiceForm.setShippingZip(shippingAddress.getZip());
			paymentServiceForm.setShippingPhone(shippingAddress.getPhoneNumber1());
			paymentServiceForm.setShippingCountry(country);
		}
		if(billingAddress!=null)
		{
			paymentServiceForm.setBillingFirstName(billingAddress.getFirstName());
			paymentServiceForm.setBillingLastName(billingAddress.getLastName());
			paymentServiceForm.setBillingAddress1(billingAddress.getAddressLine1());
			paymentServiceForm.setBillingAddress2(billingAddress.getAddressLine2());
			paymentServiceForm.setBillingCity(billingAddress.getCity());
			paymentServiceForm.setBillingState(billingAddress.getStateCode());
			paymentServiceForm.setBillingZip(billingAddress.getZip());
			paymentServiceForm.setBillingPhone(billingAddress.getPhoneNumber1());
			paymentServiceForm.setBillingCountry(country);
		}
		return paymentServiceForm;
	}
}