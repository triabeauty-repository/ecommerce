package com.triabeauty.module.controllers;

import java.io.IOException;
import java.io.PrintWriter;
import java.text.DecimalFormat;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.triabeauty.enterprise.entities.product.vo.ProductSerial;
import com.triabeauty.enterprise.entities.transactional.vo.Address;
import com.triabeauty.enterprise.entities.transactional.vo.Cart;
import com.triabeauty.enterprise.service.constants.Country;
import com.triabeauty.enterprise.service.constants.StateCode;
import com.triabeauty.enterprise.service.endpoint.remote.CartServiceRemote;
import com.triabeauty.enterprise.service.endpoint.remote.CustomerServiceRemote;
import com.triabeauty.enterprise.service.endpoint.remote.ProductCatalogServiceRemote;
import com.triabeauty.enterprise.service.locator.Remote;
import com.triabeauty.enterprise.service.locator.ServiceLocator;

@Controller
public class ProductValidationController {
	private static final Logger log = LoggerFactory.getLogger(ProductValidationController.class);
	ProductCatalogServiceRemote productService = (ProductCatalogServiceRemote) ServiceLocator
			.lookUp(ProductCatalogServiceRemote.class);
	@RequestMapping("/productValidation")
	@ResponseBody
	public ModelAndView getTax(HttpServletRequest request,HttpServletResponse response) {
		final JSONObject error = new JSONObject();
		log.warn("************It is in Product Controller Start**************");
		 String serialNumber = request.getParameter("serialNumber");
		 String deviceType = request.getParameter("deviceType");
		 String country = request.getParameter("country");
		 Country countryPojo=Country.valueOf(country);
		 log.warn("country"+country+"DeviceType"+deviceType+"serialNumber"+serialNumber);
		 ProductSerial productSerial=null;
		 
		try {
			productSerial =productService.checkProductSerialWithCountryAndDeviceType(serialNumber, countryPojo, deviceType);
			log.warn("productserial"+productSerial);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			log.warn("error while getting product info");
		}
		try {
			response.setContentType("application/json");
		PrintWriter out =response.getWriter();;
		if (productSerial == null)
		{
				error.put("ERROR_MESSAGE",
						"We are unable to locate the serial number you have entered. Please contact Customer Care for assistance at 1-877-321-8742.");
				
		
		log.warn("We are unable to locate the Serial Number you have entered. Please contact customer care for assistance");
		
			

		}
		out.print(error);
		out.flush();
		out.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return null ;
	}


}
