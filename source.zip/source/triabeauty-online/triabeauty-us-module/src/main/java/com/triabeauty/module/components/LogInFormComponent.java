package com.triabeauty.module.components;

import info.magnolia.module.blossom.annotation.TabFactory;
import info.magnolia.module.blossom.annotation.Template;
import info.magnolia.module.blossom.annotation.TemplateDescription;
import info.magnolia.module.blossom.dialog.TabBuilder;
import info.magnolia.module.blossom.view.UuidRedirectView;

import javax.jcr.Node;
import javax.jcr.RepositoryException;
import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.triabeauty.enterprise.entities.transactional.vo.User;
import com.triabeauty.enterprise.service.constants.Country;
import com.triabeauty.enterprise.service.endpoint.remote.CustomerServiceRemote;
import com.triabeauty.enterprise.service.locator.ServiceLocator;
import com.triabeauty.module.beans.LogInForm;

@Controller
@Template(title = "LogIn Form", id = "tria-us-cms-module:components/login", visible = true)
@TemplateDescription(value = "user registration form ")
public class LogInFormComponent {

	private static final Logger log = LoggerFactory
			.getLogger(LogInFormComponent.class);
	
	@RequestMapping("/login")
	public ModelAndView handleRequest(
			@ModelAttribute("logInForm") LogInForm logInForm,
			BindingResult result, Node content, HttpServletRequest request, ModelMap model)
					throws RepositoryException{

		log.debug("*********Login start****************");
		String action=request.getParameter("action");
		log.debug("action: "+action);
		if ("logIn".equals(action)&&"POST".equals(request.getMethod())) {

			log.debug(" request : email :"
					+ logInForm.getEmailId());
			
			try {
				CustomerServiceRemote customerService = (CustomerServiceRemote) ServiceLocator
						.lookUp(CustomerServiceRemote.class);
				User user=customerService.authenticate(logInForm.getEmailId(), logInForm.getUserPassword(), Country.US);
				request.getSession().setAttribute("user", user);
			} catch (Exception e) {
				model.addAttribute("ERROR_MESSAGE", "The username and/or password you have entered is invalid");
				log.error("Exception occurred while registring the customer: "+e.getMessage());
				return new ModelAndView("components/logInForm.ftl");
			}

			return new ModelAndView(new UuidRedirectView("website", content
					.getProperty("successPage").getString()));
		}
		log.debug("*********Login end****************");
		return new ModelAndView("components/logInForm.ftl");
	}

	@TabFactory("LogIn Form")
	public void contentTab(TabBuilder tab) {
		tab.addUuidLink("successPage", "Success page", "");

	}
}
