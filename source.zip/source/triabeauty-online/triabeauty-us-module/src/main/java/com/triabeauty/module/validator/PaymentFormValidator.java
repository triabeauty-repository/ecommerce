package com.triabeauty.module.validator;

import org.springframework.validation.Errors;
import org.springframework.validation.ValidationUtils;
import org.springframework.validation.Validator;

import com.triabeauty.module.beans.PaymentServiceForm;

public class PaymentFormValidator implements Validator {

    
    public boolean supports(Class clazz) {
        return clazz.equals(PaymentServiceForm.class);
    }

    
    public void validate(Object target, Errors errors) {
        ValidationUtils.rejectIfEmptyOrWhitespace(errors, "cardType", "required", "Card Type is required");
        ValidationUtils.rejectIfEmptyOrWhitespace(errors, "creditCardNumber", "required", "Creditcard Number is required");
        ValidationUtils.rejectIfEmptyOrWhitespace(errors, "expiryDateMonth", "required", "Expirty Date is required");
        ValidationUtils.rejectIfEmptyOrWhitespace(errors, "expiryDateYear", "required", "Expirty Date is required");
        ValidationUtils.rejectIfEmptyOrWhitespace(errors, "cvv", "required", "cvv is required");
    }
}
