package com.triabeauty.module.utilities;

import net.tanesha.recaptcha.ReCaptcha;
import net.tanesha.recaptcha.ReCaptchaFactory;
import net.tanesha.recaptcha.ReCaptchaImpl;
import net.tanesha.recaptcha.ReCaptchaResponse;




public class ReCaptchaUtil
{
	
	private static String captchaPrivateKey = "6LcXW9ISAAAAAAJMqLtq4r5dTcmXfXHTOqwQYVHj";
	private static String captchaPublicKey = "6LcXW9ISAAAAAH7KfMEYSPnWLFPNz0N-Lzq_hXJe";

	/**
	 * This method is used to validate the enetered text with Captcha
	 * 
	 * @return boolean
	 */
	public static boolean validateReCaptcha(final String remoteAddr, final String challenge, final String responseField)
	{
		boolean valid = true;
		final ReCaptchaImpl reCaptcha = new ReCaptchaImpl();
		reCaptcha.setPrivateKey(captchaPrivateKey);
		final ReCaptchaResponse reCaptchaResponse = reCaptcha.checkAnswer(remoteAddr, challenge, responseField);
		if (!reCaptchaResponse.isValid())
		{
			valid = false;
		}
		return valid;
	}

	/**
	 * This method is used to generate the plugin for captcha
	 * 
	 * @return String
	 */
	public static String createReCaptcha()
	{
		final ReCaptcha c = ReCaptchaFactory.newReCaptcha(captchaPublicKey, captchaPrivateKey, false);
		return c.createRecaptchaHtml(null, null);
	}

}
