package com.triabeauty.module.components;

import info.magnolia.module.blossom.annotation.TabFactory;
import info.magnolia.module.blossom.annotation.Template;
import info.magnolia.module.blossom.annotation.TemplateDescription;
import info.magnolia.module.blossom.dialog.TabBuilder;
import info.magnolia.module.blossom.view.UuidRedirectView;

import javax.jcr.Node;
import javax.jcr.RepositoryException;
import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.triabeauty.enterprise.entities.transactional.vo.User;
import com.triabeauty.enterprise.service.constants.Country;
import com.triabeauty.enterprise.service.endpoint.remote.CustomerServiceRemote;
import com.triabeauty.enterprise.service.locator.ServiceLocator;
import com.triabeauty.module.beans.RegistrationForm;

@Controller
@Template(title = "Registration Form", id = "tria-us-cms-module:components/registration", visible = true)
@TemplateDescription(value = "user registration form ")
public class RegistrationFormComponent {

	private static final Logger log = LoggerFactory
			.getLogger(RegistrationFormComponent.class);
	
	@RequestMapping("/registration")
	public ModelAndView handleRequest(
			@ModelAttribute("registrationForm") RegistrationForm registrationForm,
			BindingResult result, Node content, HttpServletRequest request, ModelMap model)
					throws RepositoryException{
		log.debug("*********Registration start****************");
		String action=request.getParameter("action");
		log.debug("action: "+action);
		if(request.getSession().getAttribute("user")!=null)
		{
			return new ModelAndView(new UuidRedirectView("website", content
					.getProperty("successPage").getString()));
		}
		if ("Register".equals(action)&&"POST".equals(request.getMethod())) {

			String interested=request.getParameter("_interested");
			boolean intersetedValue=false;
			if(request.getParameter(interested)!=null)
				intersetedValue=true;
			try {
				CustomerServiceRemote customerService = (CustomerServiceRemote) ServiceLocator
						.lookUp(CustomerServiceRemote.class);
				User user = new User();
				user.setFirstName(registrationForm.getFirstName());
				user.setLastName(registrationForm.getLastName());
				user.setEmail(registrationForm.getEmail());
				user.setPassword(registrationForm.getPassword());
				user.setRegisteredCountry(Country.valueOf((String) request.getLocale().getCountry()));
				user.setSubscribedToNewsLetter(Boolean.valueOf(intersetedValue));
				user=customerService.registerCustomer(user);
				
				if(user!=null)
				{
				request.getSession().setAttribute("user", user);
				}else{
					model.addAttribute("ERROR_MESSAGE", "This email address is already being used, please select another");
					return new ModelAndView("components/registrationForm.ftl");
				}
			} catch (Exception e) {
				model.addAttribute("ERROR_MESSAGE", "This email address is already being used, please select another");
				log.error("Exception occurred while registring the customer: "+e.getMessage());
				return new ModelAndView("components/registrationForm.ftl");
			}

			log.debug("*********Registration end****************");
			return new ModelAndView(new UuidRedirectView("website", content
					.getProperty("successPage").getString()));
		}
		return new ModelAndView("components/registrationForm.ftl");
	}

	@TabFactory("Registration Form")
	public void contentTab(TabBuilder tab) {
		/*Collection<String> countries = new ArrayList<String>();
		countries.add("US");
		countries.add("JP");
		countries.add("KR");
		tab.addSelect("country", "Country", "", countries);*/
		tab.addUuidLink("successPage", "Success page", "");

	}
}
