/** 
 * Copyright (c) 2009 TRIA Beauty INC. All Rights Reserved.
 *
 * This software is the confidential and proprietary information of TRIA
 * Beauty INC ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the terms
 * of the license agreement you entered into with TRIA Beauty INC.
 *
 * TRIA Beauty INC MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY OF 
 * SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
 * PURPOSE, OR NON-INFRINGEMENT. TRIA Beauty INC SHALL NOT BE LIABLE FOR ANY
 * DAMAGES SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 **/

/**
 *FileName:payment.java
 *
 *
 *@author 
 *Created By: 
 *Reviewed By : Sivaramakrishna
 *
 *@Creation Date: ${date}
 *@Last Modified Date: <last modified date>
 *
 *@version History
 *@<history goes here>
 *Update By <User Name> on <Date of modification> for <Reason for modification>  *
 **/

package com.triabeauty.module.components;


import info.magnolia.module.blossom.annotation.TabFactory;
import info.magnolia.module.blossom.annotation.Template;
import info.magnolia.module.blossom.dialog.TabBuilder;
import info.magnolia.module.blossom.view.UuidRedirectView;

import java.util.ArrayList;
import java.util.List;

import javax.jcr.Node;
import javax.jcr.RepositoryException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.triabeauty.enterprise.entities.product.vo.Product;
import com.triabeauty.enterprise.entities.transactional.vo.Cart;
import com.triabeauty.enterprise.entities.transactional.vo.CartItem;
import com.triabeauty.enterprise.entities.transactional.vo.CreditCardDetails;
import com.triabeauty.enterprise.service.constants.CardType;
import com.triabeauty.enterprise.service.endpoint.remote.CartServiceRemote;
import com.triabeauty.enterprise.service.locator.Remote;
import com.triabeauty.module.beans.PaymentServiceForm;
import com.triabeauty.module.utilities.PaymentUtil;
import com.triabeauty.module.utilities.ShippingMethodUtil;

/**
 * Renders the contents of the shopping cart in a small summarized format.
 */
@Controller
@Template(title = "Payment Form", id = "tria-us-cms-module:components/paymentForm")
public class PaymentFormComponent {

	private static final Logger log = LoggerFactory
			.getLogger(PaymentFormComponent.class);

	@RequestMapping(value = "/paymentForm", method = RequestMethod.GET)
	public String render(@ModelAttribute PaymentServiceForm paymentServiceForm, ModelMap model, HttpSession session, HttpServletRequest request) {
		log.warn("*****Payment Render start*******");
		try {
			CartServiceRemote cartService = Remote.getCartSerice(request);
			CreditCardDetails cardDetails=cartService.getCardDetails();
			boolean easyPay=false;
			boolean replenishProduct=false;
			List<Product> easyPayProducts=new ArrayList<Product>();
			
			if(paymentServiceForm!=null)
			{
				paymentServiceForm=setCardDetails(paymentServiceForm, cardDetails);
				log.warn(paymentServiceForm.toString());
				model.addAttribute("paymentServiceForm", paymentServiceForm);
				
			}
			Cart cart=cartService.getSessionCart();
			for(CartItem cartItem:cart.getCartItems())
			{
				Product product=cartItem.getProduct();
				if(product.getSku().isEasyPayProduct())
				{
					easyPay=true;
					easyPayProducts.add(product);
				}
				if(cartItem.getProduct().getSku().isReplenishmentProduct())
				{
					replenishProduct=true;
				}
			}
			session.setAttribute("easyPay", easyPay);
			session.setAttribute("replenishProduct", replenishProduct);
			session.setAttribute("easyPayProducts", easyPayProducts);
			
			model.addAttribute("shippingMethods", ShippingMethodUtil.getShippingMethods(request,cart.getShippingAddress().getCountry()));
			model.addAttribute("cardTypes", PaymentUtil.getCardTypes());
			model.addAttribute("months", PaymentUtil.getExpiryDateMonth());
			model.addAttribute("years", PaymentUtil.getExpiryDateYear());
			model.addAttribute("ipAddress", request.getRemoteAddr());
			model.addAttribute("cart", cart);
			model.addAttribute("easyPay", easyPay);
			model.addAttribute("easyPayProducts", easyPayProducts);
			model.addAttribute("replenishProduct", replenishProduct);
		} catch (Exception e) {
			log.error("Exception occured rendering PaymentForm: "
					+ e.getMessage());
		}


		log.warn("*****Payment Render end*******");
		return "components/paymentForm.ftl";
	}
	PaymentServiceForm setCardDetails(PaymentServiceForm paymentServiceForm,CreditCardDetails cardDetails)
	{
		if(cardDetails!=null)
		{
			paymentServiceForm.setCardType(cardDetails.getCardType().toString());
			paymentServiceForm.setCreditCardNumber(cardDetails.getCardNumber());
			paymentServiceForm.setExpiryDateMonth(cardDetails.getExpiryMonth());
			paymentServiceForm.setExpiryDateYear(cardDetails.getExpiryYear());
			paymentServiceForm.setExpiryDate(cardDetails.getExpiryMonth()+"/"+cardDetails.getExpiryYear());
		}
		return paymentServiceForm;
	}
	
	@TabFactory("Content")
	public void contentTab(TabBuilder tab) {
		tab.addUuidLink("successPage", "Success page", "");
	}
	
	@RequestMapping(value = "/paymentForm", method = RequestMethod.POST)
	public ModelAndView submit(@ModelAttribute PaymentServiceForm paymentServiceForm, BindingResult result, 
			Node content, HttpServletRequest request) throws RepositoryException{
		log.warn("*****Payment Submit start*******");
		try {
			log.warn("Shipping Method: "+paymentServiceForm.getShippingMethod());
			CartServiceRemote cartService = Remote.getCartSerice(request);
			cartService.changeShippingMethod(paymentServiceForm.getShippingMethod());

			CreditCardDetails cardDetails = new CreditCardDetails();
			cardDetails.setCardNumber(paymentServiceForm.getCreditCardNumber());
			cardDetails.setCvv(paymentServiceForm.getCvv());
			cardDetails.setCardType(CardType.valueOf(paymentServiceForm.getCardType()));
			cardDetails.setExpiryMonth(paymentServiceForm.getExpiryDateMonth());
			cardDetails.setExpiryYear(paymentServiceForm.getExpiryDateYear());
			
			cartService.setCardDetails(cardDetails);
			cartService.setSingnatureRequired(paymentServiceForm.isSignature());
		} catch (Exception e) {
			log.error("Exception occured while saving card details to cart: "
					+ e.getMessage());
		}
		log.warn("*****Payment submit End*******");
		return new ModelAndView(new UuidRedirectView("website", content
				.getProperty("successPage").getString()));

	}

	
}