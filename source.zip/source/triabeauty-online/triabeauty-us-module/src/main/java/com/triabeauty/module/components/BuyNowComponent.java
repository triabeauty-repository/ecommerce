package com.triabeauty.module.components;

import info.magnolia.module.blossom.annotation.TabFactory;
import info.magnolia.module.blossom.annotation.Template;
import info.magnolia.module.blossom.dialog.TabBuilder;
import info.magnolia.module.blossom.view.UuidRedirectView;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.jcr.Node;
import javax.jcr.Property;
import javax.jcr.RepositoryException;
import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.triabeauty.enterprise.entities.product.vo.Product;
import com.triabeauty.enterprise.entities.transactional.vo.Cart;
import com.triabeauty.enterprise.entities.transactional.vo.CartItem;
import com.triabeauty.enterprise.service.constants.Country;
import com.triabeauty.enterprise.service.endpoint.remote.CartServiceRemote;
import com.triabeauty.enterprise.service.endpoint.remote.ProductCatalogServiceRemote;
import com.triabeauty.enterprise.service.locator.Remote;
import com.triabeauty.enterprise.service.locator.ServiceLocator;

@Controller
@Template(title = "buyNow", id = "tria-us-cms-module:components/buyNow")
public class BuyNowComponent {

	private static final Logger log = LoggerFactory
			.getLogger(BuyNowComponent.class);
	private static final String CHANNEL = "WEB";
	private static final String CURRENCY = "USD";

	@RequestMapping(value = "/buyNow", method = RequestMethod.GET)
	public <product> String render(ModelMap model, Node content, HttpServletRequest request)
			throws Exception {
		log.warn("********** BuyNow Start **********");
		Property productCode = content.getProperty("productCode");
		log.warn("productCode: "+productCode.getValue()
				.getString());
		List<Product> products = null;
		Map<String,String> colorEasyPayProducts=new HashMap<String,String>();
		Map<String,String> bundleProducts=new HashMap<String,String>();
		Integer productLineId = null;
		try {
			ProductCatalogServiceRemote service = (ProductCatalogServiceRemote) ServiceLocator
					.lookUp(ProductCatalogServiceRemote.class);
			CartServiceRemote cartService = Remote.getCartSerice(request);
			Cart cart=cartService.getSessionCart();
			if (productCode != null) {
				products = service.getProducts(Country.valueOf(request.getLocale().getCountry()), productCode.getValue()
						.getString().trim());
			}
			log.warn("Products: "+products.size());
			
			if (!products.isEmpty()) {

				Product product = products.get(0);

				log.warn("SKU code: "+ product.getSku().getCode());
				productLineId=product.getSku().getProductLine().getProductLineId();
				model.put("productName", product.getSku().getProductLine().getProductLineTitle());
				model.put("productDesc", product.getSku().getProductLine().getDescription());
				if (!product.getPriceList().isEmpty()) {
					model.put("productPrice", product.getPriceList()
							.get(0).getDisplayPrice());
				}
				for(Product product1:products)
				{
					if(product1.getSku().isEasyPayProduct())
					{
						colorEasyPayProducts.put(product1.getSku().getColor().getColorCode().toLowerCase(), product1.getSku().getSkuCode());
					}
					if(product1.getSku().getVariantType().getVariantCode().equalsIgnoreCase("Bundle"))
					{
						bundleProducts.put(product1.getSku().getColor().getColorCode().toLowerCase(), product1.getSku().getSkuCode());
						if (!product1.getPriceList().isEmpty()) {
							model.put("bundleProductPrice", product1.getPriceList()
									.get(0).getDisplayPrice());
						}
						model.put("bundleProductName", product1.getSku().getProductLine().getProductLineTitle());
						model.put("bundleAdditionalText", product1.getSku().getAdditionalText());
					}
					if(product1.getSku().isReplenishmentProduct())
					{
						if (!product1.getPriceList().isEmpty()) {
							model.put("replenishmentProductPrice", product1.getPriceList()
									.get(0).getDisplayPrice());
						}
					}
					if(product1.getSku().isDevice())
					{
						model.put("isDevice", product1.getSku().isDevice());
					}
				}
				for(CartItem cartItem:cart.getCartItems())
				{
					
				}
			}
			
			model.put("products", products);
			model.put("colorEasyPayProducts", colorEasyPayProducts);
			model.put("bundleProducts", bundleProducts);
			
			log.warn("colorEasyPayProducts: "+colorEasyPayProducts);
			log.warn("bundleProducts: "+bundleProducts);
			log.warn("productLineId: "+productLineId);
			products=service.getRecommendedProducts(String.valueOf(productLineId.intValue()));
			model.put("recommendedProducts", products );
			log.warn("recommendedProducts: "+products);
		} catch (Exception e) {
			e.printStackTrace();
			log.error("Exception occured while retrieving the product info: "
					+ e.getMessage());
		}
		log.warn("********** BuyNow End **********");
		return "components/buyNow.ftl";
	}

	@TabFactory("ProductInfo")
	public void addDialog(TabBuilder tab) {
		tab.addEdit("productCode", "Product Code", "");
		tab.addEdit("buttonStyle", "Button Style", "");
		tab.addEdit("buttonLabel", "Button Label", "");
		tab.addEdit("shippingMethodText", "Shipping Method Text", "");
		tab.addEdit("saveText", "Save FSA/HSA Text", "Save FSA/HSA Text");
		tab.addEdit("guranteeText", "money-back guarantee text", "money-back guarantee text");
		tab.addUuidLink("successPage", "Success page", "");
	}

	@RequestMapping(value = "/buyNow", method = RequestMethod.POST)
	public ModelAndView submit(ModelMap model,
			Node content, HttpServletRequest request)
					throws RepositoryException {

		String skuCode=request.getParameter("productCode");
		log.warn("skuCode from Request: " + skuCode);

		String easyPayCode=request.getParameter("buyNowEasyPay");
		log.warn("easyPayCode from Request: " + easyPayCode);
		try {
			CartServiceRemote cartService = Remote.getCartSerice(request);

			if (easyPayCode == null && StringUtils.isNotBlank(skuCode))
			{
				cartService.addToCart(skuCode, CURRENCY, CHANNEL);
			}else if (StringUtils.isNotBlank(easyPayCode))
			{
				cartService.addToCart(easyPayCode, CURRENCY, CHANNEL);
			}

		} catch (Exception e) {
			log.error("Exception occured while adding the product to cart: "
					+ e.getMessage());
		}

		return new ModelAndView(new UuidRedirectView("website", content
				.getProperty("successPage").getString()));
	}
}
