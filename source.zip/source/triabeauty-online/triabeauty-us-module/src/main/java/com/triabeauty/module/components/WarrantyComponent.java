package com.triabeauty.module.components;

import info.magnolia.module.blossom.annotation.TabFactory;
import info.magnolia.module.blossom.annotation.Template;
import info.magnolia.module.blossom.annotation.TemplateDescription;
import info.magnolia.module.blossom.dialog.TabBuilder;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import javax.jcr.Node;
import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.triabeauty.enterprise.entities.product.vo.ActivationDeviceType;
import com.triabeauty.enterprise.entities.product.vo.AgeGroup;
import com.triabeauty.enterprise.entities.product.vo.HearAbout;
import com.triabeauty.enterprise.entities.product.vo.ProductSerial;
import com.triabeauty.enterprise.entities.product.vo.Warranty;
import com.triabeauty.enterprise.entities.transactional.vo.EmailSubscription;
import com.triabeauty.enterprise.service.constants.Country;
import com.triabeauty.enterprise.service.constants.Gender;
import com.triabeauty.enterprise.service.endpoint.remote.CustomerServiceRemote;
import com.triabeauty.enterprise.service.endpoint.remote.MailServiceRemote;
import com.triabeauty.enterprise.service.endpoint.remote.ProductCatalogServiceRemote;
import com.triabeauty.enterprise.service.locator.ServiceLocator;
import com.triabeauty.module.beans.WarrantyServiceForm;

@Controller
@Template(title = "RegisterWarranty", id = "tria-us-cms-module:components/registerWarranty", visible = true)
@TemplateDescription(value = "Warranty Form")
public class WarrantyComponent {
	CustomerServiceRemote customerService = (CustomerServiceRemote) ServiceLocator
			.lookUp(CustomerServiceRemote.class);
	ProductCatalogServiceRemote productService = (ProductCatalogServiceRemote) ServiceLocator
			.lookUp(ProductCatalogServiceRemote.class);
	MailServiceRemote mailService = (MailServiceRemote) ServiceLocator
			.lookUp(MailServiceRemote.class);

	private static final Logger log = LoggerFactory
			.getLogger(WarrantyComponent.class);

	@RequestMapping(value = "/registerWarranty", method = RequestMethod.GET)
	public String render(
			@ModelAttribute("warrantyForm") WarrantyServiceForm warrantyForm,
			BindingResult result, Node content, HttpServletRequest request,
			ModelMap model) {
		log.warn("***********Warranty Render**************");

		model.addObject("options", getStates());
		model.addObject("hearAboutTria", hearAboutTriaList());
		model.addObject("ageRange", getAgeGroupsList());
		model.addObject("genders", genders());
		model.addObject("deviceType", activeDeviceTypes());

		model.addObject("country", countries());
		model.addObject("serialNumber", "12345678");

		return "components/warrantyForm.ftl";
	}

	@RequestMapping(value = "/registerWarranty", method = RequestMethod.POST)
	public ModelAndView submit(
			@ModelAttribute("warrantyForm") WarrantyServiceForm warrantyForm,
			BindingResult result, Node content, HttpServletRequest request,
			ModelMap model) {
		log.warn("***********Warranty Submit**************");
		log.warn("Warranty form" + warrantyForm.toString());
		log.warn("State" + warrantyForm.getCity()
				+ warrantyForm.getHearAboutTria());
		String interested = request.getParameter("_interested");
		boolean intersetedValue = false;
		
		if (request.getParameter(interested) != null)
			intersetedValue = true;
		log.warn("interested: " + interested);
		log.warn("intersetedValue: " + intersetedValue);
		Warranty warranty = new Warranty();
		warranty.setAddressLine1(warrantyForm.getAddress1());
		warranty.setAddressLine2(warrantyForm.getAddress2());
		AgeGroup age = new AgeGroup();
		age.setAgeGroupId(Integer.parseInt(warrantyForm.getAgeRange()));
		warranty.setAgeGroup(age);
		warranty.setCity(warrantyForm.getCity());
		warranty.setCountry(Country.valueOf(warrantyForm.getCountry()));
		ActivationDeviceType deviceType = new ActivationDeviceType();
		deviceType.setDeviceTypeCode(warrantyForm.getDeviceType());

		warranty.setDeviceType(deviceType);
		warranty.setEmailAddress(warrantyForm.getEmailAddress());
		warranty.setFirstName(warrantyForm.getFirstName());
		warranty.setGender(Gender.valueOf(warrantyForm.getGender()));
		HearAbout hearabout = new HearAbout();
		hearabout.setHearAboutId(Integer.parseInt(warrantyForm
				.getHearAboutTria()));
		warranty.setHearAbout(hearabout);
		warranty.setLastName(warrantyForm.getLastName());
		warranty.setPhoneNumber(warrantyForm.getPhone());
		warranty.setProductSerialNumber(warrantyForm.getSerialNumber());

		SimpleDateFormat formatter = new SimpleDateFormat("MM/dd/yyyy");
		Date date;
		try {
			date = formatter.parse(warrantyForm.getPurchaseDate());
			warranty.setPurchaseDate(date);
			log.warn("purchasedate" + date);
			Date registrationdate = new Date();
			log.warn("registrationdate" + registrationdate);
			warranty.setWarrantyRegistrationDate(registrationdate);
		} catch (ParseException e1) {
			// TODO Auto-generated catch block
			log.warn("error while formatting date");
		}

		warranty.setState(warrantyForm.getState());
		warranty.setZipCode(warrantyForm.getZip());
		log.warn("Registration Date from warranty"
				+ warranty.getWarrantyRegistrationDate());

		try {
			boolean isWarrantyRegistered = customerService.checkWarranty(
					warrantyForm.getSerialNumber(),
					warrantyForm.getEmailAddress());
			log.warn("isWarrantyRegistered" + isWarrantyRegistered);
			if (!isWarrantyRegistered) {
				customerService.warrantyRegistration(warranty);
				ProductSerial productSerial = productService
						.checkProductSerialWithCountryAndDeviceType(
								warrantyForm.getSerialNumber(),
								Country.valueOf(warrantyForm.getCountry()),
								warrantyForm.getDeviceType());
				if (productSerial != null) {
					productSerial.setRegisteredForWarranty(true);
					try {
						productSerial.setSkuCode(productSerial.getSku().getSkuCode());
						productService.saveOrUpdate(productSerial);
					} catch (Exception e) {
						e.printStackTrace();
						log.warn("error while updating product serial");
					}
				}				
				model.addObject("Success_message",
						"Warranty for Laser Hair Removal System (sn#"
								+ warrantyForm.getSerialNumber()
								+ ") has been registered.");

				log.warn("productserial" + productSerial);
				if (intersetedValue) {
					changeEmailSubsription(intersetedValue, warranty);
				}
				mailService.sendRegistrationWarrantyMail("hdonthula@adaequare.com", warrantyForm.getSerialNumber());
			} else {

				model.addObject("serialNumber", warrantyForm.getSerialNumber());
				model.addObject("options", getStates());
				model.addObject("hearAboutTria", hearAboutTriaList());
				model.addObject("ageRange", getAgeGroupsList());
				model.addObject("genders", genders());
				model.addObject("deviceType", activeDeviceTypes());

				model.addObject("country", countries());
				model.addObject(
						"error_message",
						"The serial number you have entered appears to already be in use with the email"
								+ warrantyForm.getEmailAddress()
								+ " If you think you've reached this message in error, please contact our Customer Care team at  1-877-321-TRIA for further assistance.");

				return new ModelAndView("components/warrantyForm.ftl");

			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			model.addObject("error_message", "Error while updating warranty");
			log.warn("error while updating warranty"+e.getMessage());
			model.addObject("serialNumber", warrantyForm.getSerialNumber());
			model.addObject("options", getStates());
			model.addObject("hearAboutTria", hearAboutTriaList());
			model.addObject("ageRange", getAgeGroupsList());
			model.addObject("genders", genders());
			model.addObject("deviceType", activeDeviceTypes());

			model.addObject("country", countries());
			return new ModelAndView("components/warrantyForm.ftl");
		}

		if (result.hasErrors()) {
			return new ModelAndView("components/warrantyForm.ftl");
		} else {
			return new ModelAndView("components/warrantySuccess.ftl");
		}
	}

	private void changeEmailSubsription(boolean intersetedValue,
			Warranty warranty) {

		CustomerServiceRemote customerService = (CustomerServiceRemote) ServiceLocator
				.lookUp(CustomerServiceRemote.class);

		EmailSubscription subscriptionData = new EmailSubscription();
		subscriptionData.setEmail(warranty.getEmailAddress());
		subscriptionData.setFirstName(warranty.getFirstName());
		subscriptionData.setSourceValue("tb_warranty");
		subscriptionData.setCountry(warranty.getCountry());
		subscriptionData.setSubscribed(Boolean.valueOf(intersetedValue));
		try {
			customerService.activateEmailSubscription(subscriptionData);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			log.warn("error while email subscription");
		}

	}

	@TabFactory("Warranty Form")
	public void contentTab(TabBuilder tab) {
		tab.addUuidLink("successPage", "Success page", "");

	}

	private Map genders() {
		Map<String, String> genders = new LinkedHashMap<String, String>();

		genders.put("FEMALE", "Female");
		genders.put("MALE", "Male");
		return genders;
	}

	private Map countries() {
		Map<String, String> country = new LinkedHashMap<String, String>();
		country.put("US", "USA");
		country.put("CA", "Canada");
		return country;
	}

	private Map activeDeviceTypes() {
		List<ActivationDeviceType> activeDeviceTypes = new ArrayList<ActivationDeviceType>();
		try {
			activeDeviceTypes = customerService.getActivationDeviceTypes();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			log.warn("error while getting agegroups");
		}
		Map activeDevices = new LinkedHashMap();
		activeDevices.put("", "Select your device");
		for (ActivationDeviceType activationDeviceType : activeDeviceTypes) {
			activeDevices.put(activationDeviceType.getDeviceTypeCode(),
					activationDeviceType.getDeviceTypeName());

		}

		return activeDevices;
	}

	private Map hearAboutTriaList() {
		List<HearAbout> hearAboutList = new ArrayList<HearAbout>();
		try {
			hearAboutList = customerService.gethearAboutList();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			log.warn("error while getting hearabout");
		}
		Map hearAboutTria = new LinkedHashMap();

		for (HearAbout hearAbout : hearAboutList) {
			hearAboutTria.put(hearAbout.getHearAboutId().toString(),
					hearAbout.getHearAboutValue());

		}

		return hearAboutTria;
	}

	private Map getAgeGroupsList() {
		List<AgeGroup> ageGroups = new ArrayList<AgeGroup>();
		try {
			ageGroups = customerService.getAgeGroupList();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			log.warn("error while getting agegroups");
		}

		Map ageGroupMap = new LinkedHashMap();
		for (AgeGroup ageGroup : ageGroups) {
			ageGroupMap.put(ageGroup.getAgeGroupId().toString(),
					ageGroup.getAgeGroupValue());
		}

		return ageGroupMap;
	}

	private List<String> getStates() {
		List<String> states = new ArrayList();
		states.add("Select a state");
		states.add("AK");
		states.add("AL");
		states.add("AR");
		states.add("AZ");
		states.add("CA");
		states.add("CO");
		states.add("CT");
		states.add("DE");
		states.add("FL");
		states.add("GA");
		states.add("HI");
		states.add("IA");
		states.add("ID");
		states.add("IL");
		states.add("IN");
		states.add("KS");
		states.add("KY");
		states.add("LA");
		states.add("MA");
		states.add("MD");
		states.add("ME");
		states.add("MI");
		states.add("MN");
		states.add("MO");
		states.add("MS");
		states.add("MT");
		states.add("NC");
		states.add("ND");
		states.add("NE");
		states.add("NH");
		states.add("NJ");
		states.add("NM");
		states.add("NV");
		states.add("NY");
		states.add("OH");
		states.add("OK");
		states.add("OR");
		states.add("PA");
		states.add("RI");
		states.add("SC");
		states.add("SD");
		states.add("TN");
		states.add("TX");
		states.add("UT");
		states.add("VA");
		states.add("VT");
		states.add("WA");
		states.add("WI");
		states.add("WV");
		states.add("WY");
		return states;
	}

}
