package com.triabeauty.module.components;

import info.magnolia.context.MgnlContext;
import info.magnolia.module.blossom.annotation.TabFactory;
import info.magnolia.module.blossom.annotation.Template;
import info.magnolia.module.blossom.annotation.TemplateDescription;
import info.magnolia.module.blossom.dialog.TabBuilder;
import info.magnolia.module.blossom.view.UuidRedirectView;

import javax.jcr.Node;
import javax.jcr.RepositoryException;
import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.triabeauty.enterprise.entities.product.vo.ProductSerial;
import com.triabeauty.module.beans.QuestionnaireForm;

@Controller
@Template(title = "Questionnaire", id = "tria-us-cms-module:components/questionnaire", visible = true)
@TemplateDescription(value = "Questionnaire Form ")
public class QuestionnaireComponent {

	private static final Logger log = LoggerFactory
			.getLogger(QuestionnaireComponent.class);

	@RequestMapping(value = "/Questionnaire", method = RequestMethod.GET)
	public String render(@ModelAttribute("questionnaireForm") QuestionnaireForm questionnaireForm,
			BindingResult result, Node content, HttpServletRequest request,
			ModelMap model) {
		log.warn("***********Questionnaire Render**************");

		ProductSerial productSerialModel = null;

		if (request.getSession().getAttribute("activationProductSerialModel") != null)
		{
			productSerialModel = (ProductSerial) request.getSession().getAttribute("activationProductSerialModel");
		}
		else
		{
			productSerialModel = new ProductSerial();
		}

		model.addObject("activationCode", productSerialModel.getProductActivationCode());
		
		return "components/questionnaire.ftl";
	}
	@RequestMapping(value = "/Questionnaire", method = RequestMethod.POST)
	public ModelAndView submit(
			@ModelAttribute("questionnaireForm") QuestionnaireForm questionnaireForm,
			BindingResult result, Node content, HttpServletRequest request,
			ModelMap model) throws RepositoryException{
		log.warn("***********Questionnare Submit**************");
		ModelAndView modelview=new ModelAndView();
		try{
		final String hairColor = questionnaireForm.getSelectedHairColor();
		final String skinTone = questionnaireForm.getPrimarySkinTone();
		questionnaireForm.setPrimarySkinTone(skinTone);
		questionnaireForm.setSelectedHairColor(hairColor);
		MgnlContext.setAttribute("QuestionnaireFormData", questionnaireForm);
		 modelview.setView(new UuidRedirectView("website", content.getProperty("successPage").getString()));
		}catch(Exception e){
			e.printStackTrace();
			log.warn("error in questionnare form"+e.getMessage());
			modelview.setViewName("components/questionnaire.ftl");
		}
		return modelview;
		
	}
	

	@TabFactory("Questionnaire Form")
	public void contentTab(TabBuilder tab) {
		tab.addUuidLink("successPage", "Success page", "");
	}



}
