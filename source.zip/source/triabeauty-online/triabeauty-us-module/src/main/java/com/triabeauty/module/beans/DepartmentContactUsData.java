package com.triabeauty.module.beans;

public class DepartmentContactUsData
{

	private String department;
	private String customerName;
	private String email;
	private String telephone;
	private String order;
	private String subject;
	private String comments;
	private String ccEmail;
	private String newsletter;


	/**
	 * @return the ccEmail
	 */
	public String getCcEmail()
	{
		return ccEmail;
	}

	/**
	 * @param ccEmail
	 *           the ccEmail to set
	 */
	public void setCcEmail(final String ccEmail)
	{
		this.ccEmail = ccEmail;
	}

	/**
	 * @return the telephone
	 */
	public String getTelephone()
	{
		return telephone;
	}

	/**
	 * @param telephone
	 *           the telephone to set
	 */
	public void setTelephone(final String telephone)
	{
		this.telephone = telephone;
	}

	/**
	 * @return the order
	 */
	public String getOrder()
	{
		return order;
	}

	/**
	 * @param order
	 *           the order to set
	 */
	public void setOrder(final String order)
	{
		this.order = order;
	}

	/**
	 * @return the subject
	 */
	public String getSubject()
	{
		return subject;
	}

	/**
	 * @param subject
	 *           the subject to set
	 */
	public void setSubject(final String subject)
	{
		this.subject = subject;
	}

	/**
	 * @return the newsletter
	 */
	public String getNewsletter()
	{
		return newsletter;
	}

	/**
	 * @param newsletter
	 *           the newsletter to set
	 */
	public void setNewsletter(final String newsletter)
	{
		this.newsletter = newsletter;
	}

	/**
	 * @return the departMent
	 */
	public String getDepartment()
	{
		return department;
	}

	/**
	 * @return the customerName
	 */
	public String getCustomerName()
	{
		return customerName;
	}

	/**
	 * @param customerName
	 *           the customerName to set
	 */
	public void setCustomerName(final String customerName)
	{
		this.customerName = customerName;
	}

	/**
	 * @param departMent
	 *           the departMent to set
	 */
	public void setDepartment(final String department)
	{
		this.department = department;
	}

	public String getEmail()
	{
		return email;
	}

	/**
	 * @param email
	 *           the email to set
	 */
	public void setEmail(final String email)
	{
		this.email = email;
	}

	/**
	 * @return the comments
	 */
	public String getComments()
	{
		return comments;
	}

	/**
	 * @param comments
	 *           the comments to set
	 */
	public void setComments(final String comments)
	{
		this.comments = comments;
	}
}