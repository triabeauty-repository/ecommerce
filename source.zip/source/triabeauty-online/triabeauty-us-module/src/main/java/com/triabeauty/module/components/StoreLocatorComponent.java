package com.triabeauty.module.components;

import info.magnolia.module.blossom.annotation.TabFactory;
import info.magnolia.module.blossom.annotation.Template;
import info.magnolia.module.blossom.annotation.TemplateDescription;
import info.magnolia.module.blossom.dialog.TabBuilder;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.triabeauty.enterprise.entities.product.vo.Store;
import com.triabeauty.enterprise.service.constants.Country;
import com.triabeauty.enterprise.service.endpoint.remote.ProductCatalogServiceRemote;
import com.triabeauty.enterprise.service.locator.ServiceLocator;

@Controller
@Template(title = "StoreLocatorComponent", id = "tria-us-cms-module:components/storeLocator", visible = true)
@TemplateDescription(value = "StoreLocator Form")
public class StoreLocatorComponent {

	private static final Logger log = LoggerFactory
			.getLogger(StoreLocatorComponent.class);

	ProductCatalogServiceRemote storeLocatorService = (ProductCatalogServiceRemote) ServiceLocator
			.lookUp(ProductCatalogServiceRemote.class);
	@RequestMapping(value = "/storeLocator")
	public ModelAndView submit( HttpServletRequest request,HttpServletResponse response,
			ModelMap model) throws Exception{
		log.warn("***********StoreLocator**************");

		ModelAndView modelview=new ModelAndView();

		final List<String> names = new ArrayList();
		final List<String> addresses = new ArrayList();
		final List<String> lats = new ArrayList();
		final List<String> lags = new ArrayList();
		final List<String> distance = new ArrayList();
		Country country=Country.valueOf("US");
		if (request.getParameter("latitude") != null)
		{
			if (Double.parseDouble(request.getParameter("latitude")) > 0)
			{
				String action=request.getParameter("action");
				String addressInput=request.getParameter("addressInput");
				final Double longitude = Double.parseDouble(request.getParameter("longitude"));
				final Double latitude = Double.parseDouble(request.getParameter("latitude"));
				final int radius = Integer.parseInt(request.getParameter("radiusSelect"));
				final String[] productSelected = request.getParameterValues("productName");
				
				final List<Store> result = storeLocatorService.getStoreByLatlng(latitude, longitude, radius, productSelected, country);
				log.warn("result size"+result.size());
				if (result != null && result.size() > 0)
				{
					for (int i = 0; i < result.size(); i++)
					{
						String address = result.get(i).getLocation().getAddress().getAddressLine1();
						if (result.get(i).getLocation().getAddress().getAddressLine2() != null)
						{
							address = address + "<br> " + result.get(i).getLocation().getAddress().getAddressLine2();
						}
						if (result.get(i).getLocation().getAddress().getCity() != null)
						{
							address = address + "<br> " + result.get(i).getLocation().getAddress().getCity()+ ", ";
						}
						else
						{
							address = address + "<br> ";
						}
						log.warn("result.get(i).getLocation().getAddress().getCity()"+result.get(i).getLocation().getAddress().getCity());

						address = address + result.get(i).getLocation().getAddress().getStateCode()+ " "
								+ result.get(i).getLocation().getAddress().getZip();
						if (result.get(i).getPhoneNumber() != null)
						{
							address = address + "<br>" +result.get(i).getPhoneNumber();
						}

						if (result.get(i).getURL() != null)
						{
							address = address + "<br><a href='http://" + result.get(i).getURL()
									+ "' target='_new' rel='nofollow'>" + result.get(i).getURL() + "</a>";
						}

						address = address + "<br /><br />";

						if (result.get(i).getLHRAvailable())
						{
							address = address
									+ "<a href=\'tria-laser-hair-removal-system\'><img src=\'"+request.getContextPath()+"/docroot/img/bgs/us/global/LHRS_green.gif\' alt=\'Laser Hair Removal\'></a>";
						}

						if (result.get(i).getBLAAvailable())
						{
							address = address
									+ "<a href=\'tria-be-clear-starter-kit-clarifying-blue-light-starter-kit\'><span style=\'padding-left:8px;\'><img src=\'"+request.getContextPath()+"/docroot/img/bgs/us/global/SCS_blue.gif\' alt=\'Skin Clarifying System\'></span></a>";
						}


						address = address + "<br />";
						addresses.add(address);
						if (result.get(i).getStoreTitle() != null)
						{
							names.add(result.get(i).getStoreTitle());
						}
						else
						{
							names.add("");
						}
						lats.add(result.get(i).getLocation().getLatitude().toString());
						lags.add(result.get(i).getLocation().getLongitude().toString());
						distance.add(storeLocatorService.getDistance(longitude, latitude, (result.get(i).getLocation()
								.getLongitude())/1000000, result.get(i).getLocation().getLatitude()/1000000)
								+ "");
					}
				}
				model.addObject("names", names);
				model.addObject("addresses", addresses);
				model.addObject("lats", lats);
				model.addObject("lags", lags);
				model.addObject("distance", distance);
				model.addObject("action",action);
				model.addObject("addressInput", addressInput);
				model.addObject("selectedProducts", productSelected);
			}
		}
		
		modelview.setViewName("components/storeLocator.ftl");
		//modelAndView.addObject("from", "contactController");

		return modelview;
		
	}
	

	@TabFactory("StoreLocator Form")
	public void contentTab(TabBuilder tab) {
		tab.addUuidLink("successPage", "Success page", "");
		tab.addUuidLink("logInPage", "LogIn page", "");
	}
	

	


}
