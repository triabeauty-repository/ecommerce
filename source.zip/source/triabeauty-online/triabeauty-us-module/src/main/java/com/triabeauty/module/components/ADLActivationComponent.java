package com.triabeauty.module.components;

import info.magnolia.context.MgnlContext;
import info.magnolia.module.blossom.annotation.TabFactory;
import info.magnolia.module.blossom.annotation.Template;
import info.magnolia.module.blossom.annotation.TemplateDescription;
import info.magnolia.module.blossom.dialog.TabBuilder;
import info.magnolia.module.blossom.view.UuidRedirectView;

import javax.jcr.Node;
import javax.jcr.RepositoryException;
import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.triabeauty.enterprise.entities.product.vo.ProductSerial;
import com.triabeauty.enterprise.entities.transactional.vo.Activation;
import com.triabeauty.enterprise.entities.transactional.vo.User;
import com.triabeauty.enterprise.service.constants.Country;
import com.triabeauty.enterprise.service.endpoint.remote.CustomerServiceRemote;
import com.triabeauty.enterprise.service.endpoint.remote.ProductCatalogServiceRemote;
import com.triabeauty.enterprise.service.locator.ServiceLocator;
import com.triabeauty.module.beans.ActivationForm;

@Controller
@Template(title = "ADL Activation", id = "tria-us-cms-module:components/registerADLActivation", visible = true)
@TemplateDescription(value = "ADL Activation Form")
public class ADLActivationComponent {
	CustomerServiceRemote customerService = (CustomerServiceRemote) ServiceLocator
			.lookUp(CustomerServiceRemote.class);
	ProductCatalogServiceRemote productService = (ProductCatalogServiceRemote) ServiceLocator
			.lookUp(ProductCatalogServiceRemote.class);

	private static final Logger log = LoggerFactory
			.getLogger(ADLActivationComponent.class);

	@RequestMapping(value = "/registerADLActivation", method = RequestMethod.GET)
	public String render(
			@ModelAttribute("activationForm") ActivationForm activationForm,
			BindingResult result, Node content, HttpServletRequest request,
			ModelMap model) {
		log.warn("***********Activation Render**************");
		User user = (User) request.getSession().getAttribute("user");
		if (user!=null)
		{
			activationForm.setEmail(user.getEmail());
			model.addObject("currentUser", user.getEmail());
		}
		else
		{
			model.addObject("currentUser", null);
		}
model.addObject("currentUser", activationForm);

		return "components/activation_adl.ftl";
	}
	
	@SuppressWarnings("deprecation")
	@RequestMapping(value = "/registerADLActivation", method = RequestMethod.POST)
	public ModelAndView submit(
			@ModelAttribute("activationForm") ActivationForm activationForm,
			BindingResult result, Node content, HttpServletRequest request,
			ModelMap model) throws RepositoryException{
		log.warn("***********Activation Submit**************");
		ModelAndView modelview=new ModelAndView();
		String opCode = request.getParameter("opCode");
		String device = request.getParameter("deviceType");
		log.warn(" device type is.." + device+"SerialNumber"+activationForm.getSerialNumber());
		boolean userCreated = false;
		ProductSerial productSerialModel = null;
		boolean flag = false;
		Country country=Country.valueOf("US");
		try {
			productSerialModel = productService.checkProductSerialWithCountryAndDeviceType(activationForm.getSerialNumber(), country, "ADL");
			request.getSession().setAttribute("activationProductSerialModel", productSerialModel);
			MgnlContext.setAttribute("activationFormData", activationForm);
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			log.warn("error while getting product serial info");
		}
		if(productSerialModel==null){
			model.addObject("noSerialNumber", "noSerialNumber");
			modelview.setViewName("components/activation.ftl");
			flag = true;
		}else if (productSerialModel.getRegisteredForActivation() != null)
		{
			if (productSerialModel.getRegisteredForActivation().booleanValue())
			{
				model.addObject("ERROR_MESSAGE", "The serial number you have entered appears to already be in use. "
						+ "If you think you've reached this message in error, please contact our "
						+ "Customer Care team at 1-877-321-TRIA for further assistance.");
				modelview.setViewName("components/activation.ftl");
				flag = true;
				log.warn("The Serial Number you have entered is already in use. Please contact customer care for assistance");
			}
		}
		if (!flag)
		{
			User user = null;
			try {
				user = customerService.loadUserByUsername(activationForm.getEmail());
			} catch (Exception e1) {
				// TODO Auto-generated catch block
				log.warn("unable to find the user");
			}
			if (user != null && user.getCustomerID()!=null)
			{
				modelview.addObject("customerExists", true);
				request.getSession().setAttribute("user",user );
				
				 Activation activationModel = null;
				try {
					activationModel = customerService.getActivationDetails(productSerialModel.getProductSerialId(), user.getCustomerID());
				} catch (Exception e) {
					// TODO Auto-generated catch block
					log.warn("unable to get the activation model");
				}

				 modelview.setView(new UuidRedirectView("website", content.getProperty("successPage").getString()));
				flag = true;
				if (activationModel != null )
				{
					if(("Success").equalsIgnoreCase(activationModel.getActivationStatus())){
					model.addObject("ERROR_MESSAGE", "The serial number you have entered appears to already be in use. "
							+ "If you think you've reached this message in error, please contact our "
							+ "Customer Care team at 1-877-321-TRIA for further assistance.");
					modelview.setViewName("components/activation.ftl");
					flag = true;
					log.warn("The Serial Number you have entered is already in use. Please contact customer care for assistance");
					}
				}


				request.getSession().setAttribute("activationQuestionModel", activationModel);
			}
			else
			{
				if (opCode != null && opCode.equalsIgnoreCase("1"))
				{
					String interested = request.getParameter("_interested");
					boolean intersetedValue = false;
					
					if (request.getParameter(interested) != null)
						intersetedValue = true;
					log.warn("interested: " + interested);
					log.warn("intersetedValue: " + intersetedValue);
					 User userData = new User();
					userData.setFirstName(activationForm.getFirstName());
					userData.setLastName(activationForm.getLastName());
					userData.setEmail(activationForm.getEmail());
					userData.setPassword(activationForm.getPassword());
				
					userData.setRegisteredCountry(Country.US);
					userData.setSubscribedToNewsLetter(intersetedValue);
					try {
						userData=customerService.registerCustomer(userData);
						request.getSession().setAttribute("user", userData);
						 modelview.setView(new UuidRedirectView("website", content.getProperty("successPage").getString()));
					} catch (Exception e) {
						// TODO Auto-generated catch block
					log.warn("error while registering user");
					}
				
				
				}
				else
				{
					modelview.setViewName("components/activation.ftl");
					model.addObject("USERSTATUS", "NOUSER");
					model.addObject("customerExists", false);
					model.addObject("EMAIL", activationForm.getEmail());
				}
			}
		}
		return modelview;
		
	}



	@TabFactory("ADL Activation Form")
	public void contentTab(TabBuilder tab) {
		tab.addUuidLink("successPage", "Success page", "");

	}

}
