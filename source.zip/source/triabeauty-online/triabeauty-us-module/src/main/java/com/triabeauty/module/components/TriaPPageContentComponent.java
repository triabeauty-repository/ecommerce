package com.triabeauty.module.components;

import info.magnolia.module.blossom.annotation.TabFactory;
import info.magnolia.module.blossom.annotation.Template;
import info.magnolia.module.blossom.dialog.TabBuilder;
import info.magnolia.module.blossom.view.UuidRedirectView;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.StringTokenizer;

import javax.jcr.Node;
import javax.jcr.Property;
import javax.jcr.RepositoryException;
import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.triabeauty.enterprise.entities.product.vo.Product;
import com.triabeauty.enterprise.entities.transactional.vo.Cart;
import com.triabeauty.enterprise.entities.transactional.vo.CartItem;
import com.triabeauty.enterprise.service.constants.Country;
import com.triabeauty.enterprise.service.endpoint.remote.CartServiceRemote;
import com.triabeauty.enterprise.service.endpoint.remote.ProductCatalogServiceRemote;
import com.triabeauty.enterprise.service.locator.Remote;
import com.triabeauty.enterprise.service.locator.ServiceLocator;

@Controller
@Template(title = "TriaPPageContent", id = "tria-us-cms-module:components/triaPPageContent")
public class TriaPPageContentComponent {

	private static final Logger log = LoggerFactory
			.getLogger(TriaPPageContentComponent.class);
	private static final String CHANNEL = "WEB";
	private static final String CURRENCY = "USD";

	@RequestMapping(value = "/triaPPageContent", method = RequestMethod.GET)
	public <product> String render(ModelMap model, Node content, HttpServletRequest request)
			throws Exception {
		Property productCode = content.getProperty("productCode");
		log.warn("productCode: "+productCode.getValue()
				.getString());
		List<Product> products = null;
		Map<String,String> colorEasyPayProducts=new HashMap<String,String>();
		Map<String,String> bundleProducts=new HashMap<String,String>();
		Map<String,Integer> colorVaraintsQty = new HashMap<String,Integer>();
		Integer productLineId = null;
		try {
			ProductCatalogServiceRemote service = (ProductCatalogServiceRemote) ServiceLocator
					.lookUp(ProductCatalogServiceRemote.class);
			CartServiceRemote cartService = Remote.getCartSerice(request);
			Cart cart=cartService.getSessionCart();
			if (productCode != null) {
				products = service.getProducts(Country.valueOf(request.getLocale().getCountry()), productCode.getValue()
						.getString().trim());
			}
			log.warn("Products: "+products.size());
			
			if (!products.isEmpty()) {

				Product product = products.get(0);
				
				log.warn("SKU code: "+ product.getSku().getCode());
				productLineId=product.getSku().getProductLine().getProductLineId();
				model.put("productName", product.getSku().getProductLine().getProductLineTitle());
				model.put("productDescription", product.getSku().getProductLine().getDescription());
				if (!product.getPriceList().isEmpty()) {
					model.put("productPrice", product.getPriceList()
							.get(0).getDisplayPrice());
				}
				for(Product product1:products)
				{
					if(product1.getSku().isPrimaryProduct())
					{
						model.put("productImage", product1.getSku().getThumbNailImagePath());
					}
					if(product1.getSku().isEasyPayProduct())
					{
						colorEasyPayProducts.put(product1.getSku().getColor().getColorCode().toLowerCase(), product1.getSku().getSkuCode());
					}
					if(product1.getSku().getVariantType().getVariantCode().equalsIgnoreCase("Bundle"))
					{
						bundleProducts.put(product1.getSku().getColor().getColorCode().toLowerCase(), product1.getSku().getSkuCode());
						if (!product1.getPriceList().isEmpty()) {
							model.put("bundleProductPrice", product1.getPriceList()
									.get(0).getDisplayPrice());
						}
						model.put("bundleProductName", product1.getSku().getProductLine().getProductLineTitle());
						model.put("bundleAdditionalText", product1.getSku().getAdditionalText());
					}
					if(product1.getSku().isReplenishmentProduct())
					{
						if (!product1.getPriceList().isEmpty()) {
							model.put("replenishmentProductPrice", product1.getPriceList()
									.get(0).getDisplayPrice());
						}
					}
					if(!cart.getCartItems().isEmpty())
					{
						for(CartItem cartItem:cart.getCartItems())
						{
							if(cartItem.getProduct().getSkuCode()!=null && cartItem.getProduct().getSkuCode().equals(product1.getSku().getSkuCode()))
							{
								model.put("productQty", cartItem.getQuantity());
							}
							if(cartItem.getProduct().getSkuCode()!=null && cartItem.getProduct().getSkuCode().equals(product1.getSku().getSkuCode()))
							{
								colorVaraintsQty.put(product1.getSku().getColor().getCode(),
										 cartItem.getQuantity());
								model.put("productQty", 0);
								break;
							}
						}
						
					}else
					{
						model.put("productQty", 0);
					}
					
					model.put("colorVaraintsQty", colorVaraintsQty);
				}
				boolean isDevice=false;
				for(Product product1:products)
				{
					if(product1.getSku().isPrimaryProduct()&&product1.getSku().isDevice())
					{
						isDevice=product1.getSku().isDevice();
						break;
					}
				}
				model.put("isDevice", isDevice);
			}
			model.put("country", request.getLocale().getCountry());
			model.put("products", products);
			model.put("colorEasyPayProducts", colorEasyPayProducts);
			model.put("bundleProducts", bundleProducts);
			products=service.getRecommendedProducts(String.valueOf(productLineId.intValue()));
			for(Product product1:products)
			{
				if(product1.getSku().isReplenishmentProduct())
				{
					if (!product1.getPriceList().isEmpty()) {
						model.put("recommendedReplenishmentProductPrice", product1.getPriceList()
								.get(0).getDisplayPrice());
					}
				}
			}
			model.put("recommendedProducts", products );
			log.warn("recommendedProducts: "+products);
		} catch (Exception e) {
			e.printStackTrace();
			log.error("Exception occured while retrieving the product info: "
					+ e.getMessage());
		}
		return "components/triaPPageContent.ftl";
	}

	@TabFactory("ProductInfo")
	public void addDialog(TabBuilder tab) {
		Collection<String> componentType = new ArrayList<String>();
		componentType.add("ProductPage");
		componentType.add("BuyNowHopUp");
		tab.addEdit("productCode", "Product Code", "");
		tab.addEdit("feature1", "Product Feature1", "");
		tab.addEdit("feature2", "Product Feature2", "");
		tab.addEdit("buttonStyle", "Button Style", "");
		tab.addEdit("buttonLabel", "Button Label", "");
		tab.addEdit("shippingMethodText", "Shipping Method Text", "");
		tab.addEdit("saveText", "Save FSA/HSA Text", "Save FSA/HSA Text");
		tab.addEdit("guranteeText", "money-back guarantee text", "money-back guarantee text");
		tab.addUuidLink("successPage", "Success page", "");
	}

	@RequestMapping(value = "/triaPPageContent", method = RequestMethod.POST)
	public ModelAndView submit(ModelMap model,
			Node content, HttpServletRequest request)
					throws RepositoryException {
		String skuCode=request.getParameter("skuCode");
		String easyPayCode=request.getParameter("easyPay");
		String action=request.getParameter("action");
		String product=request.getParameter("product");
		
		log.warn("skuCode from Request: " + skuCode);
		log.warn("easyPayCode from Request: " + easyPayCode);
		log.warn("action : " + action);
		log.warn("product from Request: " + product);
		try {
			CartServiceRemote cartService = Remote.getCartSerice(request);

			if (easyPayCode == null && StringUtils.isNotBlank(skuCode))
			{
				cartService.addToCart(skuCode, CURRENCY, CHANNEL);
			}else if (StringUtils.isNotBlank(easyPayCode))
			{
				cartService.addToCart(easyPayCode, CURRENCY, CHANNEL);
			}

			if (action.equalsIgnoreCase("addToCart") && StringUtils.isNotBlank(product))
			{
				final StringTokenizer prodCode = new StringTokenizer(product, ",");
				log.warn("product.contains "+product.contains(","));
				if(!product.contains(","))
				{
					cartService.addToCart(product, CURRENCY, CHANNEL);
				}else{
					while (prodCode.hasMoreElements())
					{
						cartService.addToCart(prodCode.nextElement().toString(), CURRENCY, CHANNEL);
					}
				}
			}
		} catch (Exception e) {
			log.error("Exception occured while adding the product to cart: "
					+ e.getMessage());
			return new ModelAndView("redirect:" + request.getRequestURL());
		}

		return new ModelAndView(new UuidRedirectView("website", content
				.getProperty("successPage").getString()));
	}
}
