package com.triabeauty.module.components;

import info.magnolia.module.blossom.annotation.TabFactory;
import info.magnolia.module.blossom.annotation.Template;
import info.magnolia.module.blossom.dialog.TabBuilder;

import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@Template(title = "Text", id = "tria-us-cms-module:components/text")
public class TextComponent {

	// @Inject
	// private SimpleService simpleService;

	@RequestMapping("/text")
	public String render(ModelMap model) throws Exception {

		System.out.println("  text component render method");

		return "components/text.ftl";
	}

	@TabFactory("Content")
	public void contentTab(TabBuilder tab) {
		tab.addEdit("heading", "Heading", "").setRequired(true);
		tab.addFckEditor("text", "Text", "");
		tab.addCheckbox("inheritable", "Inherited", "");
	}
}
