package com.triabeauty.module.components;

import info.magnolia.module.blossom.annotation.TabFactory;
import info.magnolia.module.blossom.annotation.Template;
import info.magnolia.module.blossom.annotation.TemplateDescription;
import info.magnolia.module.blossom.dialog.TabBuilder;
import info.magnolia.module.blossom.view.UuidRedirectView;

import java.util.Date;

import javax.jcr.Node;
import javax.jcr.RepositoryException;
import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.triabeauty.enterprise.entities.product.vo.ProductSerial;
import com.triabeauty.enterprise.entities.transactional.vo.Activation;
import com.triabeauty.enterprise.entities.transactional.vo.User;
import com.triabeauty.enterprise.service.endpoint.remote.CustomerServiceRemote;
import com.triabeauty.enterprise.service.endpoint.remote.MailServiceRemote;
import com.triabeauty.enterprise.service.locator.ServiceLocator;

@Controller
@Template(title = "ConfirmActivation", id = "tria-us-cms-module:components/confirmActivation", visible = true)
@TemplateDescription(value = "ConfirmActivation Form ")
public class ConfirmActivationComponent {

	private static final Logger log = LoggerFactory
			.getLogger(ConfirmActivationComponent.class);
	CustomerServiceRemote customerService = (CustomerServiceRemote) ServiceLocator
			.lookUp(CustomerServiceRemote.class);
	MailServiceRemote mailService = (MailServiceRemote) ServiceLocator
			.lookUp(MailServiceRemote.class);
	@RequestMapping(value = "/ConfirmActivation", method = RequestMethod.GET)
	public String render(HttpServletRequest request, ModelMap model) {
		log.warn("***********Confirm Activation Render**************");

		User user = (User) request.getAttribute("user");
		model.addAttribute("user", user);

		ProductSerial productSerialModel = null;

		if (request.getSession().getAttribute("activationProductSerialModel") != null)
		{
			productSerialModel = (ProductSerial) request.getSession().getAttribute("activationProductSerialModel");
		}
		else
		{
			productSerialModel = new ProductSerial();
		}
		log.warn("product activation code "+ productSerialModel.getProductActivationCode());

		model.addObject("activationCode", productSerialModel.getProductActivationCode());
		if(("ADL").equalsIgnoreCase(productSerialModel.getDeviceType())){
		return "components/confirmation_adl.ftl";
		}else{
			return "components/confirmation.ftl";
		}
	}

	@RequestMapping(value = "/ConfirmActivation", method = RequestMethod.POST)
	public ModelAndView submit( Node content, HttpServletRequest request,
			ModelMap model) throws RepositoryException{
		log.warn("***********Activation Submit**************");
		ModelAndView modelview=new ModelAndView();
		try{
		
			ProductSerial productSerialModel = null;
			User user=(User)request.getSession().getAttribute("user");
			if (request.getSession().getAttribute("activationProductSerialModel") != null)
			{
				productSerialModel = (ProductSerial) request.getSession().getAttribute("activationProductSerialModel");
				
			}
			Activation activation=new Activation();
			activation.setQuestionnaireResponse(true);
			activation.setActivationStatus("Success");
			activation.setNoOfAttempts(new Integer(0));
			activation.setProductSerialId(productSerialModel.getProductSerialId());
			activation.setCustomer(user);
			activation.setActivationDate( new Date());
			customerService.saveActivation(user, activation);
			mailService.activation(user.getEmail(), productSerialModel.getProductSerialNumber(), productSerialModel.getDeviceType());
			
		 modelview.setView(new UuidRedirectView("website", content.getProperty("successPage").getString()));
		
		}catch(Exception e){			
			log.warn("error in questionnare form"+e.getMessage());
			modelview.setViewName("components/confirmation.ftl");
		}
		return modelview;
		
	}
	

	@TabFactory("ConfirmActivation Form ")
	public void contentTab(TabBuilder tab) {
		tab.addUuidLink("successPage", "Success page", "");
	}



}
