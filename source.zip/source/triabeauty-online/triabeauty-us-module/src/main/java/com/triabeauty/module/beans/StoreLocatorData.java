package com.triabeauty.module.beans;

public class StoreLocatorData
{

	private String addressInput = "Enter address or zip code";
	private String radiusSelect;
	private double longitude;
	private double latitude;



	/**
	 * @return the latitude
	 */
	public double getLatitude()
	{
		return latitude;
	}

	/**
	 * @param latitude
	 *           the latitude to set
	 */
	public void setLatitude(final double latitude)
	{
		this.latitude = latitude;
	}

	/**
	 * @return the longitude
	 */
	public double getLongitude()
	{
		return longitude;
	}

	/**
	 * @param longitude
	 *           the longitude to set
	 */
	public void setLongitude(final double longitude)
	{
		this.longitude = longitude;
	}

	/**
	 * @return the radiusSelect
	 */
	public String getRadiusSelect()
	{
		return radiusSelect;
	}

	/**
	 * @param radiusSelect
	 *           the radiusSelect to set
	 */
	public void setRadiusSelect(final String radiusSelect)
	{
		this.radiusSelect = radiusSelect;
	}

	/**
	 * @return the addressInput
	 */
	public String getAddressInput()
	{
		return addressInput;
	}

	/**
	 * @param addressInput
	 *           the addressInput to set
	 */
	public void setAddressInput(final String addressInput)
	{
		this.addressInput = addressInput;
	}


}
