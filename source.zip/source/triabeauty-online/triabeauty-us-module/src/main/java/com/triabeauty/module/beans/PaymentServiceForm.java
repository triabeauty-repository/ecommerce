/** 
 * Copyright (c) 2009 TRIA Beauty INC. All Rights Reserved.
 *
 * This software is the confidential and proprietary information of TRIA
 * Beauty INC ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the terms
 * of the license agreement you entered into with TRIA Beauty INC.
 *
 * TRIA Beauty INC MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY OF 
 * SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
 * PURPOSE, OR NON-INFRINGEMENT. TRIA Beauty INC SHALL NOT BE LIABLE FOR ANY
 * DAMAGES SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 **/

/**
 *FileName:PaymentServiceForm.java
 *
 *
 *@author 
 *Created By: 
 *Reviewed By : 
 *
 *@Creation Date: ${date}
 *@Last Modified Date: <last modified date>
 *
 *@version History
 *@<history goes here>
 *Update By <User Name> on <Date of modification> for <Reason for modification>  *
 **/


package com.triabeauty.module.beans;

/**
 * 
 */


/**
 * @author smtagirisa
 * 
 */
public class PaymentServiceForm
{

	private String cardType;
	private String creditCardNumber;
	private String cvv;
	private String expiryDate;
	private String expiryDateMonth;
	private String expiryDateYear;
	private String amount;
	private boolean easyPay = false;

	private String shippingFirstName;
	private String invoiceNumber;
	private boolean useCreditCard = false;
	private String customerId;

	private boolean interested = true;
	private String password;
	private String repeatPassword;
	private boolean loggedIn = false;
	private boolean createAccount = false;
	private boolean signature = true;
	private boolean sameBillingAddress = true;
	private boolean cblProductPresent = false;
	private String channelPartnerEmail;
	private String mediaSource;
	private boolean replenishmentChecked = true;
	private boolean vendorPromotion = false;
	private int empId;


	private String shippingLastName;
	private String shippingAddress1;
	private String shippingAddress2;
	private String shippingCompanyName;
	private String shippingHouseName;
	private String shippingHouseNumber;
	private String shippingCounty;
	private String shippingState;
	private String shippingZip;
	private String shippingPhone;
	private String shippingPhone1;
	private String shippingPhone2;
	private String shippingPhone3;
	private String shippingFax;
	private String shippingCity;
	private String shippingCountry;

	private String billingFirstName;
	private String billingLastName;
	private String billingAddress1;
	private String billingAddress2;
	private String billingCompanyName;
	private String billingHouseName;
	private String billingHouseNumber;
	private String billingCounty;
	private String billingState;
	private String billingZip;
	private String billingPhone;
	private String billingPhone1;
	private String billingPhone2;
	private String billingPhone3;
	private String billingFax;
	private String billingCity;
	private String billingCountry;

	private String shippingMethod;

	private boolean shippingAddressAlso;
	private boolean replenishment_terms = false;
	private boolean easy_pay_terms = false;

	private String email;
	private String transactionType;
	private String transactionId;
	private String countryCode;

	public boolean isReplenishmentChecked()
	{
		return replenishmentChecked;
	}

	public void setReplenishmentChecked(final boolean replenishmentChecked)
	{
		this.replenishmentChecked = replenishmentChecked;
	}

	/**
	 * @return the mediaSource
	 */
	public String getMediaSource()
	{
		return mediaSource;
	}

	/**
	 * @param mediaSource
	 *           the mediaSource to set
	 */
	public void setMediaSource(final String mediaSource)
	{
		this.mediaSource = mediaSource;
	}

	/**
	 * @return the channelPartnerEmail
	 */
	public String getChannelPartnerEmail()
	{
		return channelPartnerEmail;
	}

	/**
	 * @param channelPartnerEmail
	 *           the channelPartnerEmail to set
	 */
	public void setChannelPartnerEmail(final String channelPartnerEmail)
	{
		this.channelPartnerEmail = channelPartnerEmail;
	}

	/**
	 * @return the cblProductPresent
	 */
	public boolean isCblProductPresent()
	{
		return cblProductPresent;
	}

	/**
	 * @param cblProductPresent
	 *           the cblProductPresent to set
	 */
	public void setCblProductPresent(final boolean cblProductPresent)
	{
		this.cblProductPresent = cblProductPresent;
	}

	/**
	 * @return the sameBillingAddress
	 */
	public boolean isSameBillingAddress()
	{
		return sameBillingAddress;
	}

	/**
	 * @param sameBillingAddress
	 *           the sameBillingAddress to set
	 */
	public void setSameBillingAddress(final boolean sameBillingAddress)
	{
		this.sameBillingAddress = sameBillingAddress;
	}

	/**
	 * @return the signature
	 */
	public boolean isSignature()
	{
		return signature;
	}

	/**
	 * @param signature
	 *           the signature to set
	 */
	public void setSignature(final boolean signature)
	{
		this.signature = signature;
	}

	/**
	 * @return the createAccount
	 */
	public boolean isCreateAccount()
	{
		return createAccount;
	}

	/**
	 * @param createAccount
	 *           the createAccount to set
	 */
	public void setCreateAccount(final boolean createAccount)
	{
		this.createAccount = createAccount;
	}





	private String uid;

	/**
	 * @return the uid
	 */
	public String getUid()
	{
		return uid;
	}

	/**
	 * @param uid
	 *           the uid to set
	 */
	public void setUid(final String uid)
	{
		this.uid = uid;
	}

	/**
	 * @param loggedIn
	 *           the loggedIn to set
	 */
	public void setLoggedIn(final boolean loggedIn)
	{
		this.loggedIn = loggedIn;
	}

	/**
	 * @return the loggedIn
	 */
	public boolean isLoggedIn()
	{
		return loggedIn;
	}

	/**
	 * @return the interested
	 */
	public boolean isInterested()
	{
		return interested;
	}

	/**
	 * @param interested
	 *           the interested to set
	 */
	public void setInterested(final boolean interested)
	{
		this.interested = interested;
	}

	/**
	 * @return the password
	 */
	public String getPassword()
	{
		return password;
	}

	/**
	 * @param password
	 *           the password to set
	 */
	public void setPassword(final String password)
	{
		this.password = password;
	}

	/**
	 * @return the repeatPassword
	 */
	public String getRepeatPassword()
	{
		return repeatPassword;
	}

	/**
	 * @param repeatPassword
	 *           the repeatPassword to set
	 */
	public void setRepeatPassword(final String repeatPassword)
	{
		this.repeatPassword = repeatPassword;
	}


	/**
	 * @return the customerId
	 */
	public String getCustomerId()
	{
		return customerId;
	}

	/**
	 * @param customerId
	 *           the customerId to set
	 */
	public void setCustomerId(final String customerId)
	{
		this.customerId = customerId;
	}

	/**
	 * @return the useCreditCard
	 */
	public boolean isUseCreditCard()
	{
		return useCreditCard;
	}

	/**
	 * @param useCreditCard
	 *           the useCreditCard to set
	 */
	public void setUseCreditCard(final boolean useCreditCard)
	{
		this.useCreditCard = useCreditCard;
	}



	/**
	 * @return the invoiceNumber
	 */
	public String getInvoiceNumber()
	{
		return invoiceNumber;
	}

	/**
	 * @param invoiceNumber
	 *           the invoiceNumber to set
	 */
	public void setInvoiceNumber(final String invoiceNumber)
	{
		this.invoiceNumber = invoiceNumber;
	}

	/**
	 * @return the expiryDateMonth
	 */
	public String getExpiryDateMonth()
	{
		return expiryDateMonth;
	}

	/**
	 * @param expiryDateMonth
	 *           the expiryDateMonth to set
	 */
	public void setExpiryDateMonth(final String expiryDateMonth)
	{
		this.expiryDateMonth = expiryDateMonth;
	}

	/**
	 * @return the expiryDateYear
	 */
	public String getExpiryDateYear()
	{
		return expiryDateYear;
	}

	/**
	 * @param expiryDateYear
	 *           the expiryDateYear to set
	 */
	public void setExpiryDateYear(final String expiryDateYear)
	{
		this.expiryDateYear = expiryDateYear;
	}





	public String getShippingCompanyName()
	{
		return shippingCompanyName;
	}

	public void setShippingCompanyName(final String shippingCompanyName)
	{
		this.shippingCompanyName = shippingCompanyName;
	}

	public String getShippingHouseName()
	{
		return shippingHouseName;
	}

	public void setShippingHouseName(final String shippingHouseName)
	{
		this.shippingHouseName = shippingHouseName;
	}

	public String getShippingHouseNumber()
	{
		return shippingHouseNumber;
	}

	public void setShippingHouseNumber(final String shippingHouseNumber)
	{
		this.shippingHouseNumber = shippingHouseNumber;
	}

	public String getShippingCounty()
	{
		return shippingCounty;
	}

	public void setShippingCounty(final String shippingCounty)
	{
		this.shippingCounty = shippingCounty;
	}

	public String getBillingCompanyName()
	{
		return billingCompanyName;
	}

	public void setBillingCompanyName(final String billingCompanyName)
	{
		this.billingCompanyName = billingCompanyName;
	}

	public String getBillingHouseName()
	{
		return billingHouseName;
	}

	public void setBillingHouseName(final String billingHouseName)
	{
		this.billingHouseName = billingHouseName;
	}

	public String getBillingHouseNumber()
	{
		return billingHouseNumber;
	}

	public void setBillingHouseNumber(final String billingHouseNumber)
	{
		this.billingHouseNumber = billingHouseNumber;
	}

	public String getBillingCounty()
	{
		return billingCounty;
	}

	public void setBillingCounty(final String billingCounty)
	{
		this.billingCounty = billingCounty;
	}

	/**
	 * @return the shippingCountry
	 */
	public String getShippingCountry()
	{
		return shippingCountry;
	}

	/**
	 * @param shippingCountry
	 *           the shippingCountry to set
	 */
	public void setShippingCountry(final String shippingCountry)
	{
		this.shippingCountry = shippingCountry;
	}

	/**
	 * @return the billingCountry
	 */
	public String getBillingCountry()
	{
		return billingCountry;
	}

	/**
	 * @param billingCountry
	 *           the billingCountry to set
	 */
	public void setBillingCountry(final String billingCountry)
	{
		this.billingCountry = billingCountry;
	}

	/**
	 * @return the transactionId
	 */
	public String getTransactionId()
	{
		return transactionId;
	}

	/**
	 * @param transactionId
	 *           the transactionId to set
	 */
	public void setTransactionId(final String transactionId)
	{
		this.transactionId = transactionId;
	}

	/**
	 * @return the transactionType
	 */
	public String getTransactionType()
	{
		return transactionType;
	}

	/**
	 * @param transactionType
	 *           the transactionType to set
	 */
	public void setTransactionType(final String transactionType)
	{
		this.transactionType = transactionType;
	}

	/**
	 * @return the email
	 */
	public String getEmail()
	{
		return email;
	}

	/**
	 * @param email
	 *           the email to set
	 */
	public void setEmail(final String email)
	{
		this.email = email;
	}

	/**
	 * @return the easy_pay_terms
	 */
	public boolean isEasy_pay_terms()
	{
		return easy_pay_terms;
	}

	/**
	 * @param easyPayTerms
	 *           the easy_pay_terms to set
	 */
	public void setEasy_pay_terms(final boolean easyPayTerms)
	{
		easy_pay_terms = easyPayTerms;
	}

	/**
	 * @return the replenishment_terms
	 */
	public boolean isReplenishment_terms()
	{
		return replenishment_terms;
	}

	/**
	 * @param replenishmentTerms
	 *           the replenishment_terms to set
	 */
	public void setReplenishment_terms(final boolean replenishmentTerms)
	{
		replenishment_terms = replenishmentTerms;
	}

	/**
	 * @return the shippingAddressAlso
	 */
	public boolean isShippingAddressAlso()
	{
		return shippingAddressAlso;
	}

	/**
	 * @param shippingAddressAlso
	 *           the shippingAddressAlso to set
	 */
	public void setShippingAddressAlso(final boolean shippingAddressAlso)
	{
		this.shippingAddressAlso = shippingAddressAlso;
	}

	/**
	 * @return the shippingMethod
	 */
	public String getShippingMethod()
	{
		return shippingMethod;
	}

	/**
	 * @param shippingMethod
	 *           the shippingMethod to set
	 */
	public void setShippingMethod(final String shippingMethod)
	{
		this.shippingMethod = shippingMethod;
	}

	/**
	 * @return the shippingFirstName
	 */
	public String getShippingFirstName()
	{
		return shippingFirstName;
	}

	/**
	 * @param shippingFirstName
	 *           the shippingFirstName to set
	 */
	public void setShippingFirstName(final String shippingFirstName)
	{
		this.shippingFirstName = shippingFirstName;
	}

	/**
	 * @return the shippingLastName
	 */
	public String getShippingLastName()
	{
		return shippingLastName;
	}

	/**
	 * @param shippingLastName
	 *           the shippingLastName to set
	 */
	public void setShippingLastName(final String shippingLastName)
	{
		this.shippingLastName = shippingLastName;
	}

	/**
	 * @return the shippingAddress1
	 */
	public String getShippingAddress1()
	{
		return shippingAddress1;
	}

	/**
	 * @param shippingAddress1
	 *           the shippingAddress1 to set
	 */
	public void setShippingAddress1(final String shippingAddress1)
	{
		this.shippingAddress1 = shippingAddress1;
	}

	/**
	 * @return the shippingAddress2
	 */
	public String getShippingAddress2()
	{
		return shippingAddress2;
	}

	/**
	 * @param shippingAddress2
	 *           the shippingAddress2 to set
	 */
	public void setShippingAddress2(final String shippingAddress2)
	{
		this.shippingAddress2 = shippingAddress2;
	}

	/**
	 * @return the shippingState
	 */
	public String getShippingState()
	{
		return shippingState;
	}

	/**
	 * @param shippingState
	 *           the shippingState to set
	 */
	public void setShippingState(final String shippingState)
	{
		this.shippingState = shippingState;
	}

	/**
	 * @return the shippingZip
	 */
	public String getShippingZip()
	{
		return shippingZip;
	}

	/**
	 * @param shippingZip
	 *           the shippingZip to set
	 */
	public void setShippingZip(final String shippingZip)
	{
		this.shippingZip = shippingZip;
	}

	/**
	 * @return the shippingPhone
	 */
	public String getShippingPhone()
	{
		return shippingPhone;
	}

	/**
	 * @param shippingPhone
	 *           the shippingPhone to set
	 */
	public void setShippingPhone(final String shippingPhone)
	{
		this.shippingPhone = shippingPhone;
	}

	/**
	 * @return the shippingFax
	 */
	public String getShippingFax()
	{
		return shippingFax;
	}

	/**
	 * @param shippingFax
	 *           the shippingFax to set
	 */
	public void setShippingFax(final String shippingFax)
	{
		this.shippingFax = shippingFax;
	}

	/**
	 * @return the shippingCity
	 */
	public String getShippingCity()
	{
		return shippingCity;
	}

	/**
	 * @param shippingCity
	 *           the shippingCity to set
	 */
	public void setShippingCity(final String shippingCity)
	{
		this.shippingCity = shippingCity;
	}

	/**
	 * @return the billingFirstName
	 */
	public String getBillingFirstName()
	{
		return billingFirstName;
	}

	/**
	 * @param billingFirstName
	 *           the billingFirstName to set
	 */
	public void setBillingFirstName(final String billingFirstName)
	{
		this.billingFirstName = billingFirstName;
	}

	/**
	 * @return the billingLastName
	 */
	public String getBillingLastName()
	{
		return billingLastName;
	}

	/**
	 * @param billingLastName
	 *           the billingLastName to set
	 */
	public void setBillingLastName(final String billingLastName)
	{
		this.billingLastName = billingLastName;
	}

	/**
	 * @return the billingAddress1
	 */
	public String getBillingAddress1()
	{
		return billingAddress1;
	}

	/**
	 * @param billingAddress1
	 *           the billingAddress1 to set
	 */
	public void setBillingAddress1(final String billingAddress1)
	{
		this.billingAddress1 = billingAddress1;
	}

	/**
	 * @return the billingAddress2
	 */
	public String getBillingAddress2()
	{
		return billingAddress2;
	}

	/**
	 * @param billingAddress2
	 *           the billingAddress2 to set
	 */
	public void setBillingAddress2(final String billingAddress2)
	{
		this.billingAddress2 = billingAddress2;
	}

	/**
	 * @return the billingState
	 */
	public String getBillingState()
	{
		return billingState;
	}

	/**
	 * @param billingState
	 *           the billingState to set
	 */
	public void setBillingState(final String billingState)
	{
		this.billingState = billingState;
	}

	/**
	 * @return the billingZip
	 */
	public String getBillingZip()
	{
		return billingZip;
	}

	/**
	 * @param billingZip
	 *           the billingZip to set
	 */
	public void setBillingZip(final String billingZip)
	{
		this.billingZip = billingZip;
	}

	/**
	 * @return the billingPhone
	 */
	public String getBillingPhone()
	{
		return billingPhone;
	}

	/**
	 * @param billingPhone
	 *           the billingPhone to set
	 */
	public void setBillingPhone(final String billingPhone)
	{
		this.billingPhone = billingPhone;
	}

	/**
	 * @return the billingFax
	 */
	public String getBillingFax()
	{
		return billingFax;
	}

	/**
	 * @param billingFax
	 *           the billingFax to set
	 */
	public void setBillingFax(final String billingFax)
	{
		this.billingFax = billingFax;
	}

	/**
	 * @return the billingCity
	 */
	public String getBillingCity()
	{
		return billingCity;
	}

	/**
	 * @param billingCity
	 *           the billingCity to set
	 */
	public void setBillingCity(final String billingCity)
	{
		this.billingCity = billingCity;
	}

	/**
	 * @return the easyPay
	 */
	public boolean isEasyPay()
	{
		return easyPay;
	}

	/**
	 * @param easyPay
	 *           the easyPay to set
	 */
	public void setEasyPay(final boolean easyPay)
	{
		this.easyPay = easyPay;
	}

	/**
	 * @return the amount
	 */
	public String getAmount()
	{
		return amount;
	}

	/**
	 * @param amount
	 *           the amount to set
	 */
	public void setAmount(final String amount)
	{
		this.amount = amount;
	}

	/**
	 * @return the cardType
	 */
	public String getCardType()
	{
		return cardType;
	}

	/**
	 * @param cardType
	 *           the cardType to set
	 */
	public void setCardType(final String cardType)
	{
		this.cardType = cardType;
	}

	/**
	 * @return the creditCardNumber
	 */
	public String getCreditCardNumber()
	{
		return creditCardNumber;
	}

	/**
	 * @param creditCardNumber
	 *           the creditCardNumber to set
	 */
	public void setCreditCardNumber(final String creditCardNumber)
	{
		this.creditCardNumber = creditCardNumber;
	}

	/**
	 * @return the cvv
	 */
	public String getCvv()
	{
		return cvv;
	}

	/**
	 * @param cvv
	 *           the cvv to set
	 */
	public void setCvv(final String cvv)
	{
		this.cvv = cvv;
	}

	/**
	 * @return the expiryDate
	 */
	public String getExpiryDate()
	{

		return getExpiryDateMonth() + "/" + getExpiryDateYear();
	}

	/**
	 * @param expiryDate
	 *           the expiryDate to set
	 */
	public void setExpiryDate(final String expiryDate)
	{
		this.expiryDate = expiryDate;
	}


	public void setVendorPromotion(final boolean vendorPromotion)
	{
		this.vendorPromotion = vendorPromotion;
	}

	public boolean isVendorPromotion()
	{
		return vendorPromotion;
	}


	public int getEmpId()
	{
		return empId;
	}

	public void setEmpId(final int empId)
	{
		this.empId = empId;
	}

	
	public String getShippingPhone1() {
		return shippingPhone1;
	}

	public void setShippingPhone1(String shippingPhone1) {
		this.shippingPhone1 = shippingPhone1;
	}

	public String getShippingPhone2() {
		return shippingPhone2;
	}

	public void setShippingPhone2(String shippingPhone2) {
		this.shippingPhone2 = shippingPhone2;
	}

	public String getShippingPhone3() {
		return shippingPhone3;
	}

	public void setShippingPhone3(String shippingPhone3) {
		this.shippingPhone3 = shippingPhone3;
	}

	public String getBillingPhone1() {
		return billingPhone1;
	}

	public void setBillingPhone1(String billingPhone1) {
		this.billingPhone1 = billingPhone1;
	}

	public String getBillingPhone2() {
		return billingPhone2;
	}

	public void setBillingPhone2(String billingPhone2) {
		this.billingPhone2 = billingPhone2;
	}

	public String getBillingPhone3() {
		return billingPhone3;
	}

	public void setBillingPhone3(String billingPhone3) {
		this.billingPhone3 = billingPhone3;
	}

	public String getCountryCode() {
		return countryCode;
	}

	public void setCountryCode(String countryCode) {
		this.countryCode = countryCode;
	}

	@Override
	public String toString() {
		return "PaymentServiceForm [cardType=" + cardType
				+ ", creditCardNumber=" + creditCardNumber + ", cvv=" + cvv
				+ ", expiryDate=" + expiryDate + ", expiryDateMonth="
				+ expiryDateMonth + ", expiryDateYear=" + expiryDateYear
				+ ", amount=" + amount + ", easyPay=" + easyPay
				+ ", shippingFirstName=" + shippingFirstName
				+ ", invoiceNumber=" + invoiceNumber + ", useCreditCard="
				+ useCreditCard + ", customerId=" + customerId
				+ ", interested=" + interested + ", password=" + password
				+ ", repeatPassword=" + repeatPassword + ", loggedIn="
				+ loggedIn + ", createAccount=" + createAccount
				+ ", signature=" + signature + ", sameBillingAddress="
				+ sameBillingAddress + ", cblProductPresent="
				+ cblProductPresent + ", channelPartnerEmail="
				+ channelPartnerEmail + ", mediaSource=" + mediaSource
				+ ", replenishmentChecked=" + replenishmentChecked
				+ ", vendorPromotion=" + vendorPromotion + ", empId=" + empId
				+ ", uid=" + uid + ", shippingLastName=" + shippingLastName
				+ ", shippingAddress1=" + shippingAddress1
				+ ", shippingAddress2=" + shippingAddress2
				+ ", shippingCompanyName=" + shippingCompanyName
				+ ", shippingHouseName=" + shippingHouseName
				+ ", shippingHouseNumber=" + shippingHouseNumber
				+ ", shippingCounty=" + shippingCounty + ", shippingState="
				+ shippingState + ", shippingZip=" + shippingZip
				+ ", shippingPhone=" + shippingPhone + ", shippingFax="
				+ shippingFax + ", shippingCity=" + shippingCity
				+ ", shippingCountry=" + shippingCountry
				+ ", billingFirstName=" + billingFirstName
				+ ", billingLastName=" + billingLastName + ", billingAddress1="
				+ billingAddress1 + ", billingAddress2=" + billingAddress2
				+ ", billingCompanyName=" + billingCompanyName
				+ ", billingHouseName=" + billingHouseName
				+ ", billingHouseNumber=" + billingHouseNumber
				+ ", billingCounty=" + billingCounty + ", billingState="
				+ billingState + ", billingZip=" + billingZip
				+ ", billingPhone=" + billingPhone + ", billingFax="
				+ billingFax + ", billingCity=" + billingCity
				+ ", billingCountry=" + billingCountry + ", shippingMethod="
				+ shippingMethod + ", shippingAddressAlso="
				+ shippingAddressAlso + ", replenishment_terms="
				+ replenishment_terms + ", easy_pay_terms=" + easy_pay_terms
				+ ", email=" + email + ", transactionType=" + transactionType
				+ ", transactionId=" + transactionId + "]";
	}

	


}
