package com.triabeauty.module.beans;



public class WarrantyServiceForm
{

	private String serialNumber;
	private String firstName;
	private String lastName;
	private String address1;
	private String address2;
	private String city;
	private String state;
	private String zip;
	private String phone;
	private String emailAddress;
	private String purchaseDate;
	private String gender="FEMALE";
	private String deviceType;
	private String ageRange;
	private String hearAboutTria;
	private String country = "US";
	private boolean interested=true;

	/**
	 * @return the interested
	 */
	public boolean isInterested()
	{
		return interested;
	}

	/**
	 * @param interested
	 *           the interested to set
	 */
	public void setInterested(final boolean interested)
	{
		this.interested = interested;
	}

	/**
	 * @return the country
	 */
	public String getCountry()
	{
		return country;
	}

	/**
	 * @param country
	 *           the country to set
	 */
	public void setCountry(final String country)
	{
		this.country = country;
	}

	/**
	 * @return the deviceType
	 */
	public String getDeviceType()
	{
		return deviceType;
	}

	/**
	 * @param deviceType
	 *           the deviceType to set
	 */
	public void setDeviceType(final String deviceType)
	{
		this.deviceType = deviceType;
	}

	/**
	 * @return the ageRange
	 */
	public String getAgeRange()
	{
		return ageRange;
	}

	/**
	 * @param ageRange
	 *           the ageRange to set
	 */
	public void setAgeRange(final String ageRange)
	{
		this.ageRange = ageRange;
	}

	/**
	 * @return the hearAboutTria
	 */
	public String getHearAboutTria()
	{
		return hearAboutTria;
	}

	/**
	 * @param hearAboutTria
	 *           the hearAboutTria to set
	 */
	public void setHearAboutTria(final String hearAboutTria)
	{
		this.hearAboutTria = hearAboutTria;
	}

	/**
	 * @return the gender
	 */
	public String getGender()
	{
		return gender;
	}

	/**
	 * @param gender
	 *           the gender to set
	 */
	public void setGender(final String gender)
	{
		this.gender = gender;
	}

	/**
	 * @return the serialNumber
	 */
	public String getSerialNumber()
	{
		return serialNumber;
	}

	/**
	 * @param serialNumber
	 *           the serialNumber to set
	 */
	public void setSerialNumber(final String serialNumber)
	{
		this.serialNumber = serialNumber;
	}

	/**
	 * @return the firstName
	 */
	public String getFirstName()
	{
		return firstName;
	}

	/**
	 * @param firstName
	 *           the firstName to set
	 */
	public void setFirstName(final String firstName)
	{
		this.firstName = firstName;
	}

	/**
	 * @return the lastName
	 */
	public String getLastName()
	{
		return lastName;
	}

	/**
	 * @param lastName
	 *           the lastName to set
	 */
	public void setLastName(final String lastName)
	{
		this.lastName = lastName;
	}

	/**
	 * @return the address1
	 */
	public String getAddress1()
	{
		return address1;
	}

	/**
	 * @param address1
	 *           the address1 to set
	 */
	public void setAddress1(final String address1)
	{
		this.address1 = address1;
	}

	/**
	 * @return the address2
	 */
	public String getAddress2()
	{
		return address2;
	}

	/**
	 * @param address2
	 *           the address2 to set
	 */
	public void setAddress2(final String address2)
	{
		this.address2 = address2;
	}

	/**
	 * @return the city
	 */
	public String getCity()
	{
		return city;
	}

	/**
	 * @param city
	 *           the city to set
	 */
	public void setCity(final String city)
	{
		this.city = city;
	}

	/**
	 * @return the state
	 */
	public String getState()
	{
		return state;
	}

	/**
	 * @param state
	 *           the state to set
	 */
	public void setState(final String state)
	{
		this.state = state;
	}

	/**
	 * @return the zip
	 */
	public String getZip()
	{
		return zip;
	}

	/**
	 * @param zip
	 *           the zip to set
	 */
	public void setZip(final String zip)
	{
		this.zip = zip;
	}

	/**
	 * @return the phone
	 */
	public String getPhone()
	{
		return phone;
	}

	/**
	 * @param phone
	 *           the phone to set
	 */
	public void setPhone(final String phone)
	{
		this.phone = phone;
	}

	/**
	 * @return the emailAddress
	 */
	public String getEmailAddress()
	{
		return emailAddress;
	}

	/**
	 * @param emailAddress
	 *           the emailAddress to set
	 */
	public void setEmailAddress(final String emailAddress)
	{
		this.emailAddress = emailAddress;
	}

	/**
	 * @return the purchaseDate
	 */
	public String getPurchaseDate()
	{
		return purchaseDate;
	}

	/**
	 * @param purchaseDate
	 *           the purchaseDate to set
	 */
	public void setPurchaseDate(final String purchaseDate)
	{
		this.purchaseDate = purchaseDate;
	}

}
