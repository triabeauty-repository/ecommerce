package com.triabeauty.module.components;

import info.magnolia.module.blossom.annotation.TabFactory;
import info.magnolia.module.blossom.annotation.Template;
import info.magnolia.module.blossom.annotation.TemplateDescription;
import info.magnolia.module.blossom.dialog.TabBuilder;

import java.util.List;

import javax.jcr.Node;
import javax.jcr.RepositoryException;
import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.triabeauty.enterprise.entities.transactional.vo.Address;
import com.triabeauty.enterprise.entities.transactional.vo.PaymentForm;
import com.triabeauty.enterprise.entities.transactional.vo.ReplenishmentQueue;
import com.triabeauty.enterprise.entities.transactional.vo.User;
import com.triabeauty.enterprise.service.constants.AddressType;
import com.triabeauty.enterprise.service.constants.CardType;
import com.triabeauty.enterprise.service.constants.Country;
import com.triabeauty.enterprise.service.constants.Region;
import com.triabeauty.enterprise.service.endpoint.remote.ReplenishmentServiceRemote;
import com.triabeauty.enterprise.service.locator.ServiceLocator;
import com.triabeauty.module.beans.PaymentServiceForm;
import com.triabeauty.module.utilities.PaymentUtil;

@Controller
@Template(title = "replenishmentOrderHistory", id = "tria-us-cms-module:components/replenishmentOrderHistory", visible = true)
@TemplateDescription(value = "Order History")
public class ReplenishmentOrderHistory {

	private static final Logger log = LoggerFactory
			.getLogger(ReplenishmentOrderHistory.class);

	@RequestMapping(value = "/replenishmentOrderHistory", method = RequestMethod.GET)
	public String render(HttpServletRequest request, ModelMap model) {
		log.warn("***********replenishmentOrderHistory Render start**************");
		String replenishmentId = request.getParameter("replenishmentId");

		log.warn("replenishmentId: " + replenishmentId);
		try {
			ReplenishmentServiceRemote replenishmentService = (ReplenishmentServiceRemote) ServiceLocator
					.lookUp(ReplenishmentServiceRemote.class);
			List<ReplenishmentQueue> replenishmentOrderHistoryList = null;
			if (replenishmentId == null) {
				User user = (User) request.getSession().getAttribute("user");

				if (user != null) {

					replenishmentOrderHistoryList = replenishmentService
							.getReplenishmentOrders(user.getEmail());
					log.warn("replenishmentOrderHistoryList size: "
							+ replenishmentOrderHistoryList.size());
					request.getSession().setAttribute("replenishmentOrderHistoryList", replenishmentOrderHistoryList);
					model.addAttribute("replenishmentOrderHistoryList", replenishmentOrderHistoryList);
					return "components/replenishmentOrderHistory.ftl";
				}
			} else {
				ReplenishmentQueue replenishmentData=replenishmentService.getReplenishmentOrderDetails(replenishmentId);
				request.getSession().setAttribute("replenishmentData", replenishmentData);
				model.addAttribute("replenishmentData", replenishmentData);
				model.addAttribute("cardTypes", PaymentUtil.getCardTypes());
				model.addAttribute("months", PaymentUtil.getExpiryDateMonth());
				model.addAttribute("years", PaymentUtil.getExpiryDateYear());
				return "components/replenishmentTrackerDetails.ftl";
			}
		} catch (Exception e) {
			e.printStackTrace();
			log.error("Exception while retrieving Replenishment order history:"
					+ e.getMessage());
		}
		log.warn("***********replenishmentOrderHistory Render end**************");
		return "components/replenishmentOrderHistory.ftl";
	}

	@RequestMapping(value = "/replenishmentOrderHistory", method = RequestMethod.POST)
	public String submit(@ModelAttribute PaymentServiceForm paymentServiceForm,
			ModelMap model, Node content,
			HttpServletRequest request) throws RepositoryException {
		log.warn("*****replenishmentOrderHistory Submit*******");
		boolean flag=false;
		String action=request.getParameter("action");
		String replenishmentId = request.getParameter("replenishmentId");
		ReplenishmentServiceRemote replenishmentService = (ReplenishmentServiceRemote) ServiceLocator
				.lookUp(ReplenishmentServiceRemote.class);
		log.warn("action: " + action);
		log.warn("replenishmentId: " + replenishmentId);
		ReplenishmentQueue replenishmentData=null;
		try {
			if ("updateFrequency".equals(action)) {
				String frequency = request.getParameter("frequency");
				log.warn("frequency: " + frequency);
					flag=replenishmentService.updateReplenishFrequency(replenishmentId, frequency);
					if(flag)
					{
						model.addAttribute("SUCCESS_MESSAGE", "Delivery frequency is successfully updated");
					}else
					{
						model.addAttribute("ERROR_MESSAGE", "Delivery frequency is not updated");
					}
			} else if ("shipNow".equals(action)) {
				
					model.addAttribute("replenishmentData", request.getSession().getAttribute("replenishmentData"));
					return "components/confirmEditReplenishmentDetails.ftl";
			}else if ("confirmShipNow".equals(action)) {
					flag=replenishmentService.shipReplenishNow(replenishmentId);
					if(flag)
					{
						model.addAttribute("SUCCESS_MESSAGE", "Thank you! Your request has been received and is being processed.");
					}else
					{
						model.addAttribute("ERROR_MESSAGE", "ShipNow Request has not been processed.");
					}
			}  else if ("cancel".equals(action)) {
					model.addAttribute("replenishmentData", request.getSession().getAttribute("replenishmentData"));
					return "components/confirmCancelReplenishment.ftl";
			}else if ("confirmCancel".equals(action)) {
					flag=replenishmentService.cancelReplenish(replenishmentId);
					if(flag)
					{
						model.addAttribute("SUCCESS_MESSAGE", "Thank you! Your request has been received and is being processed.");
					}else
					{
						model.addAttribute("ERROR_MESSAGE", "Cancel Request has not been processed.");
					}
			} else if ("editShipping".equals(action)) {
					log.warn("PaymentServiceForm: " + paymentServiceForm.toString());
					try {
						editShippingAddress(paymentServiceForm, request);
						model.addAttribute("SUCCESS_MESSAGE", "Shipping Address updated successfully");
					} catch (Exception e) {
						model.addAttribute("ERROR_MESSAGE", "Shipping Address has not been updated.");
						e.printStackTrace();
						
					}
					
			}else{
				log.warn("PaymentServiceForm: " + paymentServiceForm.toString());
				String message="Failed";
				try {
					message=editPaymentInfo(paymentServiceForm, request);
					if(message.equalsIgnoreCase("Success"))
					{
						model.addAttribute("SUCCESS_MESSAGE", "Payment Information updated successfully");
					}else{
						model.addAttribute("ERROR_MESSAGE", "Payment Information has not been updated.");
					}
				} catch (Exception e) {
					e.printStackTrace();
					
				}
			}
			replenishmentData = replenishmentService.getReplenishmentOrderDetails(replenishmentId);
		} catch (Exception e) {
			e.printStackTrace();
		}
		model.addAttribute("cardTypes", PaymentUtil.getCardTypes());
		model.addAttribute("months", PaymentUtil.getExpiryDateMonth());
		model.addAttribute("years", PaymentUtil.getExpiryDateYear());
		model.addAttribute("replenishmentData", replenishmentData);
		return "components/replenishmentTrackerDetails.ftl";
	}

	private void editShippingAddress(PaymentServiceForm paymentServiceForm,
			HttpServletRequest request) throws Exception {

		log.warn("*****replenishmentOrderHistory editShippingAddress start*******");

		Address shippingAddress = new Address();
		String shippingAddressId=request.getParameter("shippingAddressId");
		String country="US";
		Region region=Region.NORTH_AMERICAN;
		if(paymentServiceForm.getCountryCode()!=null && paymentServiceForm.getCountryCode().equalsIgnoreCase("CAN"))
		{
			country="CA";
		}
		shippingAddress.setAddressId(Integer.parseInt(shippingAddressId));
		shippingAddress.setAddressType(AddressType.SHIPPING);
		shippingAddress.setFirstName(paymentServiceForm.getShippingFirstName());
		shippingAddress.setLastName(paymentServiceForm.getShippingLastName());
		shippingAddress.setAddressLine1(paymentServiceForm
				.getShippingAddress1());
		shippingAddress.setAddressLine2(paymentServiceForm
				.getShippingAddress2());
		shippingAddress.setCity(paymentServiceForm.getShippingCity());
		shippingAddress.setCountry(Country.valueOf(country));
		shippingAddress.setStateCode(paymentServiceForm.getShippingState());
		if(country.equalsIgnoreCase(Country.US.getCode())||country.equalsIgnoreCase(Country.CA.getCode()))
		{
			shippingAddress.setRegion(Region.NORTH_AMERICAN);
		}else{
			shippingAddress.setRegion(Region.ASIA_PACIFIC);
		}
		
		shippingAddress.setRegion(Region.NORTH_AMERICAN);
		shippingAddress.setZip(paymentServiceForm.getShippingZip());
		shippingAddress.setPhoneNumber1(paymentServiceForm.getShippingPhone());

		ReplenishmentServiceRemote replenishmentService = (ReplenishmentServiceRemote) ServiceLocator
				.lookUp(ReplenishmentServiceRemote.class);
			replenishmentService.updateShippingAddress(shippingAddress);
		
		log.warn("*****replenishmentOrderHistory editShippingAddress end*******");
	}
	
	private String editPaymentInfo(PaymentServiceForm paymentServiceForm,
			HttpServletRequest request)throws Exception {

		log.warn("*****editPaymentInfo start*******");
		String message="Failed";
		ReplenishmentServiceRemote replenishmentService = (ReplenishmentServiceRemote) ServiceLocator
				.lookUp(ReplenishmentServiceRemote.class);
		String billingAddressId=request.getParameter("billingAddressId");
		String authorizeProfileID=request.getParameter("authorizeProfileID");
		String orderNumber=request.getParameter("orderNumber");
		String email=request.getParameter("email");
		log.warn("*billingAddressId: "+billingAddressId);
		log.warn("*authorizeProfileID: "+authorizeProfileID);
		log.warn("*orderNumber: "+orderNumber);
		log.warn("*email: "+email);
		String country="US";
		if(paymentServiceForm.getCountryCode().equalsIgnoreCase("CAN"))
		{
			country="CA";
		}
		PaymentForm paymentForm=new PaymentForm();
		paymentForm.setBillingFirstName(paymentServiceForm.getBillingFirstName());
		paymentForm.setBillingLastName(paymentServiceForm.getBillingLastName());
		paymentForm.setBillingAddress1(paymentServiceForm.getBillingAddress1());
		paymentForm.setBillingAddress2(paymentServiceForm.getBillingAddress2());
		paymentForm.setBillingCity(paymentServiceForm.getBillingCity());
		paymentForm.setBillingState(paymentServiceForm.getBillingState());
		paymentForm.setBillingZip(paymentServiceForm.getBillingZip());
		paymentForm.setBillingCountry(country);
		paymentForm.setBillingPhone(paymentServiceForm.getBillingPhone1());
		paymentForm.setSubscriptionId(authorizeProfileID);
		paymentForm.setOrderNumber(orderNumber);
		paymentForm.setEmail(email);
		paymentForm.setExpiryMonth(paymentServiceForm.getExpiryDateMonth());
		paymentForm.setExpiryYear(paymentServiceForm.getExpiryDateYear());
		paymentForm.setCvv(paymentServiceForm.getCvv());
		paymentForm.setCardNumber(paymentServiceForm.getCreditCardNumber());
		paymentForm.setCardType(CardType.valueOf(paymentServiceForm.getCardType()));

		if(billingAddressId!=null)
		{
		message= replenishmentService.updatePaymentAddress(paymentForm, Integer.parseInt(billingAddressId));
		}
		log.warn("*****editPaymentInfo end*******");
		return message;
	}
	
	@TabFactory("replenishmentOrderHistory")
	public void contentTab(TabBuilder tab) {
		tab.addStatic("This component requires no configuration");
		tab.addEdit("linkTitle", "Back Link Title", "Back Link Title");
		tab.addLink("link", "Link", "Back Link");
	}

}
